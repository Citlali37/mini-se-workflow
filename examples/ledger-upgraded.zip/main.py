"""本地支出记账工具入口。

从 stdin 读取一个 JSON 对象，执行一次请求，向 stdout 写出一个 JSON 对象，
退出码恒为 0。所有状态通过当前工作目录下的 expenses.json 跨进程保留。
"""

import sys

import handlers
import protocol


def configure_stdio() -> None:
    """尽量把标准流切换为 UTF-8，避免本地化编码影响 JSON 的读写。"""
    streams = (sys.stdin, sys.stdout)
    for stream in streams:
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            continue


def main() -> int:
    configure_stdio()
    try:
        data = sys.stdin.read()
    except Exception:
        data = ""

    try:
        request = protocol.read_request(data)
        response = handlers.dispatch(request)
    except Exception:
        response = {"ok": False, "error": "unknown_action"}

    try:
        protocol.write_response(response)
    except Exception:
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
