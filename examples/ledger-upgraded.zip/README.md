# 本地支出记账工具

一个仅使用 Python 3.10+ 标准库的小型本地工具：从 stdin 读取一个 JSON 请求，
执行一次操作，向 stdout 输出一个 JSON 响应，退出码恒为 0。
所有数据保存在**当前工作目录**下的 `expenses.json`，因此可以跨进程保留状态。

## 使用方法

```bash
echo '{"action": "add", "amount": 500, "category": "Food"}' | python main.py
```

每次调用都是一个新进程；进程之间唯一的共享状态就是当前工作目录下的 `expenses.json`。

## 请求协议

- 从 stdin 读取的内容必须是一个 JSON 对象；空输入、非法 JSON 或顶层不是对象时，
  等价于缺少 `action`，返回 `unknown_action`。
- 只执行一次请求，stdout 只输出一个 JSON 对象，没有其他文本，退出码为 0。

### action: add

```json
{"action": "add", "amount": 500, "category": "Food"}
```

- `amount`：必须是 JSON 整数且大于 0（以分计）。布尔值、浮点数、字符串、null、0 和负数都非法。
- `category`：必须是字符串，去除首尾空白后不能为空；内部空白保留。
- 成功响应（`category` 为去除首尾空白后的值）：

```json
{"ok": true, "entry": {"amount": 500, "category": "Food"}}
```

### action: list

```json
{"action": "list"}
```

返回按创建顺序排列的全部条目：

```json
{"ok": true, "entries": [{"amount": 500, "category": "Food"}]}
```

没有数据时 `entries` 为空数组 `[]`。

### action: total

```json
{"action": "total"}
```

返回所有条目 `amount` 的整数总和：

```json
{"ok": true, "total": 500}
```

没有数据时 `total` 为 `0`。

## 错误行为

所有错误都以 `ok:false` 的 JSON 返回，退出码仍然为 0，且**不修改**持久化数据：

| 情况 | 响应 |
| --- | --- |
| `amount` 缺失 / 非整数 / 布尔值 / 小于等于 0 | `{"ok": false, "error": "invalid_amount"}` |
| `category` 缺失 / 非字符串 / 去空白后为空 | `{"ok": false, "error": "invalid_category"}` |
| `action` 缺失 / 非字符串 / 未识别 | `{"ok": false, "error": "unknown_action"}` |

`add` 的校验顺序为先 `amount` 后 `category`。

示例：

```bash
echo '{"action": "add", "amount": 0, "category": "X"}' | python main.py
# {"ok": false, "error": "invalid_amount"}

echo '{"action": "add", "amount": 100, "category": "   "}' | python main.py
# {"ok": false, "error": "invalid_category"}

echo '{"action": "delete"}' | python main.py
# {"ok": false, "error": "unknown_action"}

echo '{}' | python main.py
# {"ok": false, "error": "unknown_action"}
```

## 持久化格式

文件路径：`expenses.json`（当前工作目录，UTF-8 文本）。

```json
{"entries": [{"amount": 500, "category": "Food"}, {"amount": 250, "category": "B"}]}
```

- 数组顺序即创建顺序，成功的 `add` 追加到末尾。
- 文件不存在、读取失败、JSON 非法或顶层结构不合法时，视为空数据 `[]`（不报错）。
- 只有成功的 `add` 才会覆盖写入该文件；失败的请求绝不写盘。

## 文件结构

- `main.py`：进程入口，负责 stdin 读取、分发调用、stdout 输出与兜底异常处理。
- `protocol.py`：请求解析与响应写出。
- `validation.py`：`amount` / `category` 校验。
- `storage.py`：`expenses.json` 读写与容错。
- `handlers.py`：`add` / `list` / `total` 业务与错误分支。
