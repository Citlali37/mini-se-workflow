"""JSON 协议层：stdin 请求解析与 stdout 响应写出。

任何无法解析为 JSON 对象的输入都退化为空字典 {}，从而由业务层统一
判定为 unknown_action。写出时只输出一个 JSON 对象，不追加额外文本。
"""

import json
import sys


def read_request(data: str) -> dict:
    """把 stdin 文本解析为请求对象。

    空输入、非字符串、非法 JSON、或解析结果不是对象时返回 {}。
    """
    if not isinstance(data, str):
        return {}
    text = data.strip()
    if text == "":
        return {}
    try:
        parsed = json.loads(text)
    except Exception:
        return {}
    if isinstance(parsed, dict):
        return parsed
    return {}


def write_response(resp: dict) -> None:
    """把响应对象写成单个 JSON 对象并刷新缓冲区。"""
    payload = json.dumps(resp, ensure_ascii=False)
    sys.stdout.write(payload)
    sys.stdout.flush()
