"""输入校验：amount 与 category 的合法性判定。"""


def validate_amount(amount) -> bool:
    """amount 必须是 JSON 整数且严格大于 0；布尔值不被视为整数。"""
    if isinstance(amount, bool):
        return False
    if not isinstance(amount, int):
        return False
    if amount <= 0:
        return False
    return True


def validate_category(category):
    """category 必须是字符串，去除首尾空白后非空；返回清洗后的值，否则 None。"""
    if not isinstance(category, str):
        return None
    cleaned = category.strip()
    if cleaned == "":
        return None
    return cleaned
