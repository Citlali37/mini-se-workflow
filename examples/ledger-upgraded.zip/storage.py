"""持久化层：当前工作目录下 expenses.json 的读写与容错。

文件格式为单个 JSON 对象 {"entries": [{"amount": int, "category": str}, ...]}，
数组顺序即创建顺序。文件缺失或内容不可用时按空数据处理。
"""

import json
from pathlib import Path

STORAGE_PATH = "expenses.json"


def _storage_file() -> Path:
    return Path(STORAGE_PATH)


def _normalize_entry(item) -> dict:
    """把持久化中的一条记录规范为仅含 amount 与 category 的字典。"""
    if not isinstance(item, dict):
        return {}
    amount = item.get("amount")
    category = item.get("category")
    if isinstance(amount, bool):
        return {}
    if not isinstance(amount, int):
        return {}
    if not isinstance(category, str):
        return {}
    return {"amount": amount, "category": category}


def load_entries() -> list:
    """读取全部条目；文件不存在、读取失败或结构非法时返回空列表。"""
    path = _storage_file()
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    except Exception:
        return []

    if text.strip() == "":
        return []

    try:
        data = json.loads(text)
    except Exception:
        return []

    if not isinstance(data, dict):
        return []

    raw_entries = data.get("entries")
    if not isinstance(raw_entries, list):
        return []

    entries = []
    for item in raw_entries:
        entry = _normalize_entry(item)
        if entry:
            entries.append(entry)
    return entries


def save_entries(entries: list) -> None:
    """整体覆盖写入 entries 列表。"""
    path = _storage_file()
    payload = json.dumps({"entries": entries}, ensure_ascii=False)
    path.write_text(payload, encoding="utf-8")
