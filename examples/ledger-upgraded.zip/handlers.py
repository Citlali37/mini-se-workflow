"""业务层：请求分发与 add/list/total 处理。

失败路径一律不写盘，保证非法请求零副作用。
"""

import storage
import validation

ADD = "add"
LIST = "list"
TOTAL = "total"


def dispatch(request: dict) -> dict:
    """根据 action 分发请求；未知或缺失 action 返回 unknown_action。"""
    if not isinstance(request, dict):
        return {"ok": False, "error": "unknown_action"}
    action = request.get("action")
    if not isinstance(action, str):
        return {"ok": False, "error": "unknown_action"}
    if action == ADD:
        return handle_add(request)
    if action == LIST:
        return handle_list(request)
    if action == TOTAL:
        return handle_total(request)
    return {"ok": False, "error": "unknown_action"}


def handle_add(request: dict) -> dict:
    """校验并追加一条支出记录，成功时持久化。"""
    amount = request.get("amount")
    if not validation.validate_amount(amount):
        return {"ok": False, "error": "invalid_amount"}

    cleaned = validation.validate_category(request.get("category"))
    if cleaned is None:
        return {"ok": False, "error": "invalid_category"}

    entries = storage.load_entries()
    entry = {"amount": amount, "category": cleaned}
    entries.append(entry)
    storage.save_entries(entries)
    return {"ok": True, "entry": {"amount": amount, "category": cleaned}}


def handle_list(request: dict) -> dict:
    """按创建顺序返回全部条目。"""
    entries = storage.load_entries()
    return {"ok": True, "entries": entries}


def handle_total(request: dict) -> dict:
    """返回所有条目 amount 的整数总和，空数据为 0。"""
    entries = storage.load_entries()
    total = 0
    for entry in entries:
        total += entry["amount"]
    return {"ok": True, "total": total}
