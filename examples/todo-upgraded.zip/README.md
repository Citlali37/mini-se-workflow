# todo_tool

一个使用 Python 3.10+ 标准库实现的小型本地待办事项工具。
每次运行都通过 `python main.py` 启动，从 **stdin** 读取一个 JSON 请求对象，
向 **stdout** 输出一个 JSON 响应对象，进程退出码固定为 `0`。

数据持久化在当前工作目录下的 `todos.json`，因此每次请求虽然都是新进程，
数据依然可以跨进程保留。

## 运行方式

```bash
echo '{"action": "list"}' | python main.py
```

响应（stdout 只输出一个 JSON 对象）：

```json
{"ok": true, "tasks": []}
```

也可以直接交互输入一行 JSON 后按 Ctrl-D（Windows 下 Ctrl-Z 回车）：

```bash
python main.py
{"action": "add", "title": "Buy milk"}
```

## 请求字段

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `action` | 字符串 | 必填，取值 `add` / `list` / `complete` / `delete` |
| `title` | 字符串 | `add` 使用，去除首尾空白后不能为空 |
| `id` | JSON 正整数（>= 1） | `complete` / `delete` 使用 |

其他字段一律忽略；布尔值 `true`/`false` 不被视为整数。

## 各 action 的请求与响应

### add

请求：

```json
{"action": "add", "title": "  Buy milk  "}
```

成功响应（标题仅去除首尾空白，内部空白保留）：

```json
{"ok": true, "task": {"id": 1, "title": "Buy milk", "completed": false}}
```

### list

请求：

```json
{"action": "list"}
```

成功响应（按创建顺序排列，无任务时为空数组）：

```json
{"ok": true, "tasks": [{"id": 1, "title": "Buy milk", "completed": false}]}
```

### complete

请求：

```json
{"action": "complete", "id": 1}
```

成功响应。对已完成任务重复调用是幂等的，仍返回 `ok: true`：

```json
{"ok": true, "task": {"id": 1, "title": "Buy milk", "completed": true}}
```

### delete

请求：

```json
{"action": "delete", "id": 1}
```

成功响应：

```json
{"ok": true, "deleted_id": 1}
```

## 错误行为

所有错误都返回 `{"ok": false, "error": "<标识>"}`，退出码仍为 `0`，
并且失败请求 **不会修改数据**：

| error | 触发条件 |
| --- | --- |
| `unknown_action` | `action` 缺失、不是字符串、未知动作，或输入为空 / 不是合法 JSON 对象 |
| `empty_title` | `add` 的 `title` 缺失、非字符串或去除首尾空白后为空 |
| `invalid_id` | `complete` / `delete` 的 `id` 缺失、非整数、布尔值、0 或负数 |
| `not_found` | `id` 是合法正整数，但当前没有对应任务 |

示例：

```bash
echo '{"action": "add", "title": "   "}' | python main.py
# {"ok": false, "error": "empty_title"}

echo '{"action": "complete", "id": true}' | python main.py
# {"ok": false, "error": "invalid_id"}

echo '{"action": "delete", "id": 99}' | python main.py
# {"ok": false, "error": "not_found"}

echo '{"action": "nope"}' | python main.py
# {"ok": false, "error": "unknown_action"}
```

校验顺序：先校验 `action`，再校验 `title`（add）或 `id`（complete/delete），
最后校验任务是否存在。

## 编号规则

- 编号从 `1` 开始，只在成功 `add` 时递增。
- 失败请求不占用编号。
- 删除后编号不复用。

## 存储格式

当前工作目录下的 `todos.json`：

```json
{
  "next_id": 3,
  "tasks": [
    {"id": 1, "title": "A", "completed": true},
    {"id": 3, "title": "C", "completed": false}
  ]
}
```

- 文件不存在、为空或 JSON 解析失败时视为空状态 `{"next_id": 1, "tasks": []}`。
- 字段缺失或类型异常时做最小兼容：`tasks` 非数组按空数组处理，`next_id` 非正整数按 `1` 处理。
- 写入使用 UTF-8 编码、`ensure_ascii=False`，先写临时文件再原子替换。
- 只有发生实际变更的请求才写盘。
