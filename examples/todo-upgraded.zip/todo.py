"""todo_tool 业务逻辑：校验请求并修改内存状态。

handle_request(request, state) -> (response, changed)
changed 为 True 时表示状态被修改，需要写盘。
"""

import storage

KNOWN_ACTIONS = ("add", "list", "complete", "delete")


def _is_positive_int(value):
    """判断是否为 JSON 正整数（布尔值不算整数）。"""
    if isinstance(value, bool):
        return False
    if not isinstance(value, int):
        return False
    return value >= 1


def _clean_title(value):
    """校验并清洗标题；非法或空白返回 None。"""
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if stripped == "":
        return None
    return stripped


def _find_task(tasks, task_id):
    """按 id 查找任务，找不到返回 None。"""
    for task in tasks:
        if task["id"] == task_id:
            return task
    return None


def _public_task(task):
    """构造对外输出的任务对象。"""
    return {
        "id": task["id"],
        "title": task["title"],
        "completed": task["completed"],
    }


def _error(name):
    return {"ok": False, "error": name}


def handle_request(request, state):
    """处理单个请求，返回 (response, changed)。"""
    if not isinstance(request, dict):
        return _error("unknown_action"), False

    action = request.get("action")
    if not isinstance(action, str) or action not in KNOWN_ACTIONS:
        return _error("unknown_action"), False

    tasks = state.get("tasks")
    if not isinstance(tasks, list):
        tasks = []
        state["tasks"] = tasks

    if action == "add":
        title = _clean_title(request.get("title"))
        if title is None:
            return _error("empty_title"), False
        next_id = state.get("next_id")
        if not _is_positive_int(next_id):
            next_id = 1
        task = {"id": next_id, "title": title, "completed": False}
        tasks.append(task)
        state["next_id"] = next_id + 1
        return {"ok": True, "task": _public_task(task)}, True

    if action == "list":
        return {"ok": True, "tasks": [_public_task(t) for t in tasks]}, False

    task_id = request.get("id")
    if not _is_positive_int(task_id):
        return _error("invalid_id"), False

    task = _find_task(tasks, task_id)
    if task is None:
        return _error("not_found"), False

    if action == "complete":
        task["completed"] = True
        return {"ok": True, "task": _public_task(task)}, True

    tasks.remove(task)
    return {"ok": True, "deleted_id": task_id}, True
