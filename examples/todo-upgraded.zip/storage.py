"""todo_tool 持久化模块：读写当前工作目录下的 todos.json。

状态结构：{"next_id": int, "tasks": [{"id": int, "title": str, "completed": bool}, ...]}
"""

import json
from pathlib import Path

DEFAULT_PATH = "todos.json"


def empty_state():
    """返回空状态。"""
    return {"next_id": 1, "tasks": []}


def _normalize_next_id(value, tasks):
    """校正 next_id：非正整数按 1 处理，且必须大于所有现存 id。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        value = 1
    for task in tasks:
        if task["id"] >= value:
            value = task["id"] + 1
    return value


def _normalize_task(item):
    """把原始条目规范化为任务对象；非法条目返回 None。"""
    if not isinstance(item, dict):
        return None
    task_id = item.get("id")
    if isinstance(task_id, bool) or not isinstance(task_id, int) or task_id < 1:
        return None
    title = item.get("title")
    if not isinstance(title, str):
        return None
    completed = item.get("completed")
    if not isinstance(completed, bool):
        completed = False
    return {"id": task_id, "title": title, "completed": completed}


def load_state(path=DEFAULT_PATH):
    """读取状态；文件不存在、无法读取或解析失败时返回空状态。"""
    file_path = Path(path)
    try:
        text = file_path.read_text(encoding="utf-8")
    except Exception:
        return empty_state()

    try:
        data = json.loads(text)
    except Exception:
        return empty_state()

    if not isinstance(data, dict):
        return empty_state()

    raw_tasks = data.get("tasks")
    tasks = []
    if isinstance(raw_tasks, list):
        for item in raw_tasks:
            task = _normalize_task(item)
            if task is not None:
                tasks.append(task)

    return {"next_id": _normalize_next_id(data.get("next_id"), tasks), "tasks": tasks}


def save_state(state, path=DEFAULT_PATH):
    """以 UTF-8 原子写入状态：先写同目录临时文件再替换目标文件。"""
    file_path = Path(path)
    tasks = state.get("tasks")
    if not isinstance(tasks, list):
        tasks = []
    next_id = state.get("next_id")
    if isinstance(next_id, bool) or not isinstance(next_id, int) or next_id < 1:
        next_id = 1

    payload = {
        "next_id": next_id,
        "tasks": [_normalize_task(t) for t in tasks if _normalize_task(t) is not None],
    }
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"

    tmp_path = file_path.with_name(file_path.name + ".tmp")
    tmp_path.write_text(text, encoding="utf-8")
    tmp_path.replace(file_path)
