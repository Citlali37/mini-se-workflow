"""todo_tool 入口模块：stdin 读取一个 JSON 请求，stdout 输出一个 JSON 响应。

退出码固定为 0；业务错误与解析错误均以 JSON 对象返回。
"""

import json
import sys

import storage
import todo


def read_request():
    """从 stdin 读取并解析请求对象；空输入或无法解析时返回 None。"""
    try:
        raw = sys.stdin.read()
    except Exception:
        return None
    if not isinstance(raw, str):
        return None
    text = raw.strip()
    if text == "":
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


def write_response(response):
    """把响应对象以单个 JSON 文本写入 stdout。"""
    text = json.dumps(response, ensure_ascii=False)
    sys.stdout.write(text)
    sys.stdout.write("\n")
    try:
        sys.stdout.flush()
    except Exception:
        pass


def main():
    """处理一次请求并返回，进程退出码始终为 0。"""
    request = read_request()
    try:
        state = storage.load_state()
    except Exception:
        state = storage.empty_state()

    changed = False
    if request is None:
        response = {"ok": False, "error": "unknown_action"}
    else:
        try:
            response, changed = todo.handle_request(request, state)
        except Exception:
            response = {"ok": False, "error": "unknown_action"}
            changed = False

    if changed:
        try:
            storage.save_state(state)
        except Exception:
            response = {"ok": False, "error": "unknown_action"}

    write_response(response)


if __name__ == "__main__":
    main()
