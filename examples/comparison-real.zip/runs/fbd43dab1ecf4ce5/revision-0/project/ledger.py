"""业务层：校验规则与 add/list/total 的响应构造。

校验顺序固定：action（在 main 中判定） -> amount -> category。
非法 add 在校验阶段直接返回错误，绝不触发持久化写入。
"""

import storage

KNOWN_ACTIONS = ("add", "list", "total")


def check_amount(value):
    """amount 必须是 JSON 整数且 > 0；布尔、浮点、字符串、null、缺失均非法。"""
    if isinstance(value, bool):
        return False
    if not isinstance(value, int):
        return False
    return value > 0


def normalize_category(value):
    """category 必须是字符串，strip 后非空；否则返回 None。"""
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if stripped == "":
        return None
    return stripped


def handle_add(request, entries, data_path):
    """校验并按创建顺序追加一条记录；成功后原子写入持久化文件。"""
    amount = request.get("amount")
    if not check_amount(amount):
        return {"ok": False, "error": "invalid_amount"}

    category = normalize_category(request.get("category"))
    if category is None:
        return {"ok": False, "error": "invalid_category"}

    entry = {"amount": amount, "category": category}
    updated = []
    for existing in entries:
        updated.append({"amount": existing["amount"], "category": existing["category"]})
    updated.append(entry)

    storage.save_entries(data_path, updated)
    return {"ok": True, "entry": {"amount": amount, "category": category}}


def handle_list(entries):
    """按创建顺序返回全部条目。"""
    items = []
    for existing in entries:
        items.append({"amount": existing["amount"], "category": existing["category"]})
    return {"ok": True, "entries": items}


def handle_total(entries):
    """返回全部 amount 之和；无条目时为 0（Python int 无溢出）。"""
    total = 0
    for existing in entries:
        total += existing["amount"]
    return {"ok": True, "total": total}
