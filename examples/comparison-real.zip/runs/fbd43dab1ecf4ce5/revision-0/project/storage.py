"""持久化层：./expenses.json 的读取与原子写入。

读取语义：
  * 文件不存在 -> 视为空库 []（不创建文件）。
  * 文件存在但不可读/JSON 解析失败/结构非法 -> 抛 StorageCorrupted，
    绝不当作空库继续写入。
写入语义：
  * 先写同目录临时文件，再 Path.replace 原子替换；失败抛 StorageWriteError
    并删除临时文件，原文件内容保持不变。
"""

import json
from pathlib import Path


class StorageCorrupted(Exception):
    """数据文件存在但无法解析或结构非法。"""


class StorageWriteError(Exception):
    """写入或原子替换失败。"""


def load_entries(path):
    """读取并校验条目列表，返回 [{'amount': int, 'category': str}, ...]。"""
    target = Path(path)
    try:
        exists = target.exists()
    except OSError:
        raise StorageCorrupted("path check failed")
    if not exists:
        return []

    try:
        raw = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError, ValueError):
        raise StorageCorrupted("unreadable data file")

    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        raise StorageCorrupted("invalid json")

    if not isinstance(data, dict):
        raise StorageCorrupted("top level is not an object")

    raw_entries = data.get("entries")
    if not isinstance(raw_entries, list):
        raise StorageCorrupted("entries is not a list")

    entries = []
    for item in raw_entries:
        if not isinstance(item, dict):
            raise StorageCorrupted("entry is not an object")
        amount = item.get("amount")
        category = item.get("category")
        if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
            raise StorageCorrupted("entry amount invalid")
        if not isinstance(category, str):
            raise StorageCorrupted("entry category invalid")
        entries.append({"amount": amount, "category": category})
    return entries


def save_entries(path, entries):
    """以原子方式把 entries 写入 path。"""
    target = Path(path)
    payload = {"entries": []}
    for item in entries:
        payload["entries"].append({"amount": item["amount"], "category": item["category"]})
    try:
        text = json.dumps(payload, ensure_ascii=False, indent=2)
    except (ValueError, TypeError):
        raise StorageWriteError("serialization failed")

    temp_path = target.with_name(target.name + ".tmp")

    try:
        temp_path.write_text(text, encoding="utf-8")
    except (OSError, UnicodeEncodeError, ValueError):
        _discard(temp_path)
        raise StorageWriteError("temporary write failed")

    try:
        temp_path.replace(target)
    except OSError:
        _discard(temp_path)
        raise StorageWriteError("atomic replace failed")


def _discard(temp_path):
    """尽力删除临时文件，忽略清理失败。"""
    try:
        if temp_path.exists():
            temp_path.unlink()
    except OSError:
        return
