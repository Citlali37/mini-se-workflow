"""expense_ledger 入口。

从 stdin 读取恰好一个 JSON 对象，执行一次请求，向 stdout 输出恰好一个 JSON 对象。
任何输入（含空输入、非法 JSON、非对象输入、未知 action、校验失败、存储错误）
都以 JSON 响应结束，退出码恒为 0。
"""

import json
import sys
from pathlib import Path

import ledger
import storage

# 持久化文件：当前工作目录下的相对路径
DATA_FILE = Path("expenses.json")


def run(stdin_text):
    """执行一次请求并返回响应 dict（不打印任何东西）。"""
    try:
        request = json.loads(stdin_text)
    except (ValueError, TypeError):
        request = {}
    if not isinstance(request, dict):
        request = {}

    action = request.get("action")
    if not isinstance(action, str) or action not in ledger.KNOWN_ACTIONS:
        return {"ok": False, "error": "unknown_action"}

    try:
        entries = storage.load_entries(DATA_FILE)
    except storage.StorageCorrupted:
        return {"ok": False, "error": "storage_corrupted"}

    if action == "list":
        return ledger.handle_list(entries)
    if action == "total":
        return ledger.handle_total(entries)

    try:
        return ledger.handle_add(request, entries, DATA_FILE)
    except storage.StorageWriteError:
        return {"ok": False, "error": "storage_write_failed"}


def main():
    """读取 stdin -> run -> 写出 stdout，永远正常退出（exit code 0）。"""
    try:
        stdin_text = sys.stdin.read()
    except (OSError, UnicodeDecodeError, ValueError):
        stdin_text = ""

    try:
        response = run(stdin_text)
    except storage.StorageCorrupted:
        response = {"ok": False, "error": "storage_corrupted"}
    except storage.StorageWriteError:
        response = {"ok": False, "error": "storage_write_failed"}
    except Exception:
        response = {"ok": False, "error": "storage_corrupted"}

    text = json.dumps(response, ensure_ascii=False)
    try:
        sys.stdout.write(text)
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
