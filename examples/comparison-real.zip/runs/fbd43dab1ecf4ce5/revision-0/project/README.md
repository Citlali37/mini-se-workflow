# expense_ledger

小型本地支出记账工具，仅使用 Python 3.10+ 标准库，无第三方依赖、无网络、无子进程。

## 运行方式

```
python main.py
```

进程从 **stdin 读取恰好一个 JSON 对象**，向 **stdout 输出恰好一个 JSON 对象**，
处理完一次请求后退出，退出码恒为 `0`（业务错误也以 JSON 返回，不抛栈、不写日志）。
每次请求都是新进程；需要持久化的数据保存在**当前工作目录**下的相对路径 `./expenses.json`。

## 请求协议

请求形如 `{"action": "add" | "list" | "total", ...}`。

### add

```json
{"action": "add", "amount": 100, "category": "  food  "}
```

成功响应（category 已去除首尾空白并以去空白后的值存储）：

```json
{"ok": true, "entry": {"amount": 100, "category": "food"}}
```

- `amount` 必须是 JSON 整数且 `> 0`；缺失、布尔值、浮点数、字符串、`null`、`0`、
  负数一律返回 `{"ok": false, "error": "invalid_amount"}`。
- `category` 必须是字符串且 `strip()` 后非空；缺失、非字符串、空串或仅空白的字符串
  返回 `{"ok": false, "error": "invalid_category"}`。
- 校验顺序固定：先判 action，再判 amount，最后判 category。
- 校验失败**不写入**持久化数据，不影响后续 `list` / `total` 结果。

### list

```json
{"action": "list"}
```

```json
{"ok": true, "entries": [{"amount": 100, "category": "food"}]}
```

按创建顺序（append 顺序，不排序、不去重）返回全部条目；空库返回 `[]`。

### total

```json
{"action": "total"}
```

```json
{"ok": true, "total": 350}
```

为全部已存储 `amount` 之和；空库为 `0`。使用 Python 任意精度整数，不存在溢出回绕。

## 错误行为

所有错误响应形如 `{"ok": false, "error": "<id>"}`，错误 id 全集：

| error id               | 触发条件                                                     |
| ---------------------- | ------------------------------------------------------------ |
| `unknown_action`       | `action` 缺失、非字符串，或不是 `add` / `list` / `total`      |
| `invalid_amount`       | `amount` 缺失/非整数（含布尔、浮点、字符串、null）/`<= 0`     |
| `invalid_category`     | `category` 缺失/非字符串/去首尾空白后为空                     |
| `storage_corrupted`    | `expenses.json` 存在但不可读、JSON 解析失败或结构非法         |
| `storage_write_failed` | 写临时文件或原子替换失败（原数据文件保持不变）                |

stdin 为空、不是合法 JSON、或不是 JSON 对象时，等价于 `action` 缺失，返回
`{"ok": false, "error": "unknown_action"}`。

## 持久化

存储文件：当前工作目录下的 `./expenses.json`（UTF-8），格式为：

```json
{"entries": [{"amount": 100, "category": "food"}]}
```

- 文件**不存在**：视为空库 `[]`（读取时不创建文件；成功 add 后才创建）。
- 文件**存在但损坏/不可读/结构非法**（顶层非对象、`entries` 非数组、条目非对象、
  `amount` 非正整数 int、`category` 非字符串）：返回 `storage_corrupted`，
  **不按空库继续处理，也不覆盖写入**，原文件保留。
- 写入采用「同目录临时文件 `expenses.json.tmp` 写完整 JSON + `Path.replace` 原子替换」；
  写入或替换任一步失败时删除临时文件、返回 `storage_write_failed`，旧文件内容不变。

## 示例

```
$ echo '{"action":"add","amount":250,"category":"  transport  "}' | python main.py
{"ok": true, "entry": {"amount": 250, "category": "transport"}}

$ echo '{"action":"total"}' | python main.py
{"ok": true, "total": 250}

$ echo '{"action":"add","amount":0,"category":"food"}' | python main.py
{"ok": false, "error": "invalid_amount"}
```
