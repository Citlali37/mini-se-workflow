#!/usr/bin/env python3
"""文本统计工具：从标准输入读取一个 JSON 对象，统计字符数、英文单词数与行数。"""

import json
import re
import sys

# 连续 ASCII 字母或数字构成的英文单词
WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")


def count_text(text: str) -> tuple:
    """返回 (characters, words, lines)。"""
    characters = len(text)                 # 含空格与换行
    words = len(WORD_PATTERN.findall(text))
    lines = len(text.splitlines())         # 空字符串为 0 行
    return characters, words, lines


def load_request(raw_bytes: bytes):
    """解析 stdin 内容，返回 (payload, error_code)。"""
    if not raw_bytes.strip():
        return None, "invalid_json"
    try:
        raw_text = raw_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return None, "invalid_json"
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError:
        return None, "invalid_json"
    if not isinstance(payload, dict):
        return None, "invalid_json"
    return payload, None


def build_response(raw_bytes: bytes) -> dict:
    """根据输入构造业务响应。"""
    payload, error = load_request(raw_bytes)
    if error is not None:
        return {"ok": False, "error": error}

    if "text" not in payload:
        return {"ok": False, "error": "invalid_text"}
    text = payload["text"]
    if not isinstance(text, str):
        return {"ok": False, "error": "invalid_text"}

    characters, words, lines = count_text(text)
    return {
        "ok": True,
        "characters": characters,
        "words": words,
        "lines": lines,
    }


def main() -> int:
    try:
        raw_bytes = sys.stdin.buffer.read()
    except Exception:
        raw_bytes = b""

    try:
        response = build_response(raw_bytes)
    except Exception:
        response = {"ok": False, "error": "internal_error"}

    sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
