# 文本统计工具

一个只依赖 Python 3.10+ 标准库的本地小工具。每次调用从标准输入读取一个 JSON 对象，
统计 `text` 字段的字符数、英文单词数和行数，并向标准输出写出一个 JSON 对象。

## 运行方式

```sh
echo '{"text": "hello-world"}' | python main.py
```

每次请求都是一个新进程，不需要网络、第三方依赖、安装步骤或交互输入。

## 输出字段

| 字段 | 含义 |
| --- | --- |
| characters | 文本总字符数（包含空格与换行） |
| words | 连续 ASCII 字母或数字组成的片段个数（`hello-world` 为 2 个词） |
| lines | `text.splitlines()` 的行数（空字符串为 0 行） |

## 请求示例

英文文本：

```
输入：{"text": "hello-world"}
输出：{"ok": true, "characters": 11, "words": 2, "lines": 1}
```

中文文本：

```
输入：{"text": "你好，世界\n第二行"}
输出：{"ok": true, "characters": 9, "words": 0, "lines": 2}
```

空文本：

```
输入：{"text": ""}
输出：{"ok": true, "characters": 0, "words": 0, "lines": 0}
```

换行文本：

```
输入：{"text": "a b\nc\nd"}
输出：{"ok": true, "characters": 7, "words": 3, "lines": 3}
```

中英混合：

```
输入：{"text": "abc123 中文 mixed-case 42"}
输出：{"ok": true, "characters": 23, "words": 4, "lines": 1}
```

## 错误行为

错误同样以单个 JSON 对象返回，进程退出码保持为 0，且不会把错误当成成功结果：

| 场景 | 输出 |
| --- | --- |
| `text` 字段缺失 | `{"ok": false, "error": "invalid_text"}` |
| `text` 不是字符串（数字、null、数组、对象等） | `{"ok": false, "error": "invalid_text"}` |
| 空输入、非法 JSON、JSON 不是对象 | `{"ok": false, "error": "invalid_json"}` |

## 验收用例

1. 英文：`{"text": "hello-world"}` → `{"ok": true, "characters": 11, "words": 2, "lines": 1}`
2. 中文：`{"text": "你好，世界"}` → `{"ok": true, "characters": 5, "words": 0, "lines": 1}`
3. 空文本：`{"text": ""}` → `{"ok": true, "characters": 0, "words": 0, "lines": 0}`
4. 换行：`{"text": "a b\nc\nd"}` → `{"ok": true, "characters": 7, "words": 3, "lines": 3}`
5. 无效输入：`{"text": 123}` → `{"ok": false, "error": "invalid_text"}`
6. 无效输入：`{}` → `{"ok": false, "error": "invalid_text"}`
7. 无效输入：`not json` → `{"ok": false, "error": "invalid_json"}`
