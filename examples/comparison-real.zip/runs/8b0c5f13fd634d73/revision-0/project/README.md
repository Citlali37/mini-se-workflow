# 本地图书借阅工具（library-tool）

一个仅使用 Python 3.10+ 标准库实现的本地小工具。每次调用启动一个新进程，从 `stdin` 读取一个 JSON 请求对象，向 `stdout` 输出一个 JSON 响应对象，退出码恒为 `0`（业务错误同样以 JSON 返回）。

## 运行方式

```bash
python main.py
```

示例（Linux/macOS shell）：

```bash
echo '{"action":"add_book","book_id":"B1","title":"深入理解计算机系统","total_copies":2}' | python main.py
```

输出：

```json
{"ok":true,"book":{"book_id":"B1","title":"深入理解计算机系统","total_copies":2}}
```

不带交互提示、不需要网络、不调用子进程或系统命令。

## 数据文件

- 数据保存在**当前工作目录**下的 `library_data.json`。
- 写入流程：先写同目录临时文件 `library_data.json.tmp`，再用 `Path.replace` 原子替换目标文件；写入或替换失败返回 `storage_error` 并保留原文件。
- 文件不存在时按空库初始化；请求失败不会改变数据文件。
- 公开格式固定为：

```json
{
  "next_seq": 1,
  "books": {},
  "readers": {},
  "borrows": []
}
```

- `books`：`book_id` → `{"book_id","title","total_copies"}`
- `readers`：`reader_id` → `{"reader_id","name"}`
- `borrows`：数组，元素为 `{"seq","book_id","reader_id","borrow_date","due_date","returned","return_date"}`；未归还时 `return_date` 为 `null`，`seq` 从 1 递增。

已有文件若 JSON 损坏、缺字段、字段类型错误、引用不存在的图书/读者、存在重复未归还记录、超过库存、`seq` 重复或 `next_seq` 不大于已有最大序号，一律返回 `storage_error`，不会自动修复或覆盖。

## 请求协议

请求是一个 JSON 对象，至少包含 `action` 字段。未知或缺失的动作返回 `unknown_action`；空输入、非法 JSON、非对象 JSON 返回 `invalid_request`。

### add_book

请求：`{"action":"add_book","book_id":"B1","title":" 书名 ","total_copies":2}`

- `book_id`：非空白字符串，否则 `invalid_id`
- `title`：非空白字符串（结果去除首尾空白），否则 `invalid_title`
- `total_copies`：`>= 1` 的整数（布尔值不算），否则 `invalid_total_copies`
- 编号已存在返回 `duplicate_book_id`

成功：`{"ok":true,"book":{"book_id":"B1","title":"书名","total_copies":2}}`

### add_reader

请求：`{"action":"add_reader","reader_id":"R1","name":" 张三 "}`

- `reader_id`：非空白字符串，否则 `invalid_id`
- `name`：非空白字符串（去除首尾空白），否则 `invalid_name`
- 编号已存在返回 `duplicate_reader_id`

成功：`{"ok":true,"reader":{"reader_id":"R1","name":"张三"}}`

### borrow

请求：`{"action":"borrow","book_id":"B1","reader_id":"R1","borrow_date":"2024-01-31"}`

- 编号缺失/空白/非字符串 → `invalid_id`
- `borrow_date` 必须是严格 `YYYY-MM-DD` 且真实存在的日期；`borrow_date + 14 天` 溢出（超出日期范围）同样返回 `invalid_date`
- 图书不存在 → `book_not_found`；读者不存在 → `reader_not_found`
- 同一读者对同一本书有未归还记录 → `already_borrowed`（先于库存检查）
- 库存为 0 → `no_copies_available`
- 库存按「总副本数 − 未归还数」计算

成功：`{"ok":true,"available_copies":1,"record":{"book_id":"B1","reader_id":"R1","borrow_date":"2024-01-31","due_date":"2024-02-14","returned":false}}`

### return_book

请求：`{"action":"return_book","book_id":"B1","reader_id":"R1","return_date":"2024-02-20"}`

- 编号校验同上（`invalid_id`）；`return_date` 必须合法（`invalid_date`），不要求晚于借阅日期
- 图书不存在 → `book_not_found`；读者不存在 → `reader_not_found`
- 没有未归还记录 → `not_borrowed`

成功：`{"ok":true,"available_copies":2,"record":{"book_id":"B1","reader_id":"R1","return_date":"2024-02-20","returned":true}}`

### list_borrowed

请求：`{"action":"list_borrowed","reader_id":"R1"}`

- `reader_id` 非空白字符串，否则 `invalid_id`；读者不存在 → `reader_not_found`
- 只列出未归还记录，按借阅登记顺序

成功：`{"ok":true,"borrows":[{"book_id":"B1","title":"书名","borrow_date":"2024-01-31","due_date":"2024-02-14"}]}`

### list_overdue

请求：`{"action":"list_overdue","date":"2024-03-01","reader_id":"R1"}`（`reader_id` 可选）

- `date` 必须合法，否则 `invalid_date`；提供了 `reader_id` 时必须为非空白字符串且读者存在（`invalid_id` / `reader_not_found`）
- 只列出未归还且 `due_date < date` 的记录（应还当天不算逾期），按借阅登记顺序

成功：`{"ok":true,"overdue":[{"book_id":"B1","reader_id":"R1","title":"书名","borrow_date":"2024-01-31","due_date":"2024-02-14"}]}`

## 错误码一览

| 错误码 | 含义 |
| --- | --- |
| `invalid_request` | 空输入、非法 JSON 或非对象 JSON |
| `unknown_action` | 动作缺失或未知 |
| `invalid_id` | 编号缺失、非字符串或全为空白 |
| `invalid_title` | 书名缺失、非字符串或全为空白 |
| `invalid_total_copies` | 副本数不是 `>= 1` 的整数（布尔值不算） |
| `invalid_name` | 姓名缺失、非字符串或全为空白 |
| `invalid_date` | 日期格式非法、不存在或溢出 |
| `duplicate_book_id` | 图书编号重复 |
| `duplicate_reader_id` | 读者编号重复 |
| `book_not_found` | 图书不存在 |
| `reader_not_found` | 读者不存在 |
| `already_borrowed` | 该读者已借该书且未归还 |
| `no_copies_available` | 无可用副本 |
| `not_borrowed` | 没有对应的未归还记录 |
| `storage_error` | 数据文件损坏/不可读/结构非法，或写入失败 |
| `internal_error` | 未预期的内部异常（不会返回成功） |

所有错误响应形如：`{"ok":false,"error":"invalid_id"}`，退出码仍为 `0`。
