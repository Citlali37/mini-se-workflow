#!/usr/bin/env python3
"""本地图书借阅工具（单请求 JSON 协议）。

启动方式: python main.py
从 stdin 读取一个 JSON 对象，向 stdout 输出一个 JSON 对象，退出码恒为 0。
数据保存在当前工作目录的 library_data.json。
"""

import datetime
import json
import re
import sys
from pathlib import Path

DATA_FILENAME = "library_data.json"
TMP_FILENAME = "library_data.json.tmp"
LOAN_DAYS = 14
DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")

DATA_FILE = Path(DATA_FILENAME)
TMP_FILE = Path(TMP_FILENAME)


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
def default_data():
    return {"next_seq": 1, "books": {}, "readers": {}, "borrows": []}


def error_response(code):
    return {"ok": False, "error": code}


def is_non_empty_str(value):
    return isinstance(value, str) and value.strip() != ""


def is_positive_int(value):
    return isinstance(value, int) and not isinstance(value, bool) and value >= 1


def parse_date(value):
    """严格解析 YYYY-MM-DD，返回 datetime.date 或 None。"""
    if not isinstance(value, str) or DATE_PATTERN.match(value) is None:
        return None
    try:
        return datetime.date(int(value[0:4]), int(value[5:7]), int(value[8:10]))
    except ValueError:
        return None


# --------------------------------------------------------------------------
# 存储层
# --------------------------------------------------------------------------
def validate_data(obj):
    """校验持久化结构；合法返回该对象，否则返回 None。"""
    if not isinstance(obj, dict):
        return None
    for key in ("next_seq", "books", "readers", "borrows"):
        if key not in obj:
            return None

    next_seq = obj["next_seq"]
    books = obj["books"]
    readers = obj["readers"]
    borrows = obj["borrows"]

    if not is_positive_int(next_seq):
        return None
    if not isinstance(books, dict) or not isinstance(readers, dict):
        return None
    if not isinstance(borrows, list):
        return None

    for book_id, book in books.items():
        if not is_non_empty_str(book_id) or not isinstance(book, dict):
            return None
        if book.get("book_id") != book_id:
            return None
        if "title" not in book or not is_non_empty_str(book["title"]):
            return None
        if "total_copies" not in book or not is_positive_int(book["total_copies"]):
            return None

    for reader_id, reader in readers.items():
        if not is_non_empty_str(reader_id) or not isinstance(reader, dict):
            return None
        if reader.get("reader_id") != reader_id:
            return None
        if "name" not in reader or not is_non_empty_str(reader["name"]):
            return None

    max_seq = 0
    seen_seq = set()
    active_pairs = set()
    outstanding = {}

    for record in borrows:
        if not isinstance(record, dict):
            return None
        seq = record.get("seq")
        if not is_positive_int(seq) or seq in seen_seq:
            return None
        seen_seq.add(seq)
        if seq > max_seq:
            max_seq = seq

        book_id = record.get("book_id")
        reader_id = record.get("reader_id")
        if not isinstance(book_id, str) or book_id not in books:
            return None
        if not isinstance(reader_id, str) or reader_id not in readers:
            return None

        if parse_date(record.get("borrow_date")) is None:
            return None
        if parse_date(record.get("due_date")) is None:
            return None

        returned = record.get("returned")
        if not isinstance(returned, bool):
            return None
        return_date = record.get("return_date")
        if returned:
            if parse_date(return_date) is None:
                return None
        else:
            if return_date is not None:
                return None
            pair = (book_id, reader_id)
            if pair in active_pairs:
                return None
            active_pairs.add(pair)
            outstanding[book_id] = outstanding.get(book_id, 0) + 1

    if next_seq <= max_seq:
        return None
    for book_id, count in outstanding.items():
        if count > books[book_id]["total_copies"]:
            return None

    return obj


def load_data():
    """返回 (data, error)。文件不存在则初始化；损坏/非法/不可读返回 storage_error。"""
    if not DATA_FILE.exists():
        return default_data(), None
    try:
        raw = DATA_FILE.read_text(encoding="utf-8")
    except (OSError, ValueError, UnicodeDecodeError):
        return None, "storage_error"
    try:
        parsed = json.loads(raw)
    except ValueError:
        return None, "storage_error"
    data = validate_data(parsed)
    if data is None:
        return None, "storage_error"
    return data, None


def save_data(data):
    """同目录临时文件写入后 Path.replace；成功返回 True，失败返回 False。"""
    try:
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        return False
    try:
        TMP_FILE.write_text(payload, encoding="utf-8")
    except (OSError, ValueError, UnicodeDecodeError):
        return False
    try:
        TMP_FILE.replace(DATA_FILE)
    except (OSError, ValueError):
        try:
            TMP_FILE.unlink()
        except OSError:
            pass
        return False
    return True


def count_outstanding(data, book_id):
    total = 0
    for record in data["borrows"]:
        if record["book_id"] == book_id and not record["returned"]:
            total += 1
    return total


def available_copies(data, book_id):
    return data["books"][book_id]["total_copies"] - count_outstanding(data, book_id)


# --------------------------------------------------------------------------
# 动作处理
# --------------------------------------------------------------------------
def handle_add_book(data, request):
    book_id = request.get("book_id")
    if not is_non_empty_str(book_id):
        return error_response("invalid_id"), None
    title = request.get("title")
    if not is_non_empty_str(title):
        return error_response("invalid_title"), None
    total_copies = request.get("total_copies")
    if not is_positive_int(total_copies):
        return error_response("invalid_total_copies"), None
    if book_id in data["books"]:
        return error_response("duplicate_book_id"), None

    book = {
        "book_id": book_id,
        "title": title.strip(),
        "total_copies": total_copies,
    }
    data["books"][book_id] = book
    return {"ok": True, "book": dict(book)}, data


def handle_add_reader(data, request):
    reader_id = request.get("reader_id")
    if not is_non_empty_str(reader_id):
        return error_response("invalid_id"), None
    name = request.get("name")
    if not is_non_empty_str(name):
        return error_response("invalid_name"), None
    if reader_id in data["readers"]:
        return error_response("duplicate_reader_id"), None

    reader = {"reader_id": reader_id, "name": name.strip()}
    data["readers"][reader_id] = reader
    return {"ok": True, "reader": dict(reader)}, data


def handle_borrow(data, request):
    book_id = request.get("book_id")
    reader_id = request.get("reader_id")
    if not is_non_empty_str(book_id) or not is_non_empty_str(reader_id):
        return error_response("invalid_id"), None

    borrow_date = request.get("borrow_date")
    start = parse_date(borrow_date)
    if start is None:
        return error_response("invalid_date"), None
    try:
        due = start + datetime.timedelta(days=LOAN_DAYS)
    except (OverflowError, ValueError):
        return error_response("invalid_date"), None

    if book_id not in data["books"]:
        return error_response("book_not_found"), None
    if reader_id not in data["readers"]:
        return error_response("reader_not_found"), None

    for record in data["borrows"]:
        if (
            record["book_id"] == book_id
            and record["reader_id"] == reader_id
            and not record["returned"]
        ):
            return error_response("already_borrowed"), None

    if available_copies(data, book_id) <= 0:
        return error_response("no_copies_available"), None

    seq = data["next_seq"]
    record = {
        "seq": seq,
        "book_id": book_id,
        "reader_id": reader_id,
        "borrow_date": borrow_date,
        "due_date": due.isoformat(),
        "returned": False,
        "return_date": None,
    }
    data["borrows"].append(record)
    data["next_seq"] = seq + 1

    return (
        {
            "ok": True,
            "available_copies": available_copies(data, book_id),
            "record": {
                "book_id": book_id,
                "reader_id": reader_id,
                "borrow_date": borrow_date,
                "due_date": due.isoformat(),
                "returned": False,
            },
        },
        data,
    )


def handle_return_book(data, request):
    book_id = request.get("book_id")
    reader_id = request.get("reader_id")
    if not is_non_empty_str(book_id) or not is_non_empty_str(reader_id):
        return error_response("invalid_id"), None

    return_date = request.get("return_date")
    if parse_date(return_date) is None:
        return error_response("invalid_date"), None

    if book_id not in data["books"]:
        return error_response("book_not_found"), None
    if reader_id not in data["readers"]:
        return error_response("reader_not_found"), None

    target = None
    for record in data["borrows"]:
        if (
            record["book_id"] == book_id
            and record["reader_id"] == reader_id
            and not record["returned"]
        ):
            target = record
            break
    if target is None:
        return error_response("not_borrowed"), None

    target["returned"] = True
    target["return_date"] = return_date

    return (
        {
            "ok": True,
            "available_copies": available_copies(data, book_id),
            "record": {
                "book_id": book_id,
                "reader_id": reader_id,
                "return_date": return_date,
                "returned": True,
            },
        },
        data,
    )


def handle_list_borrowed(data, request):
    reader_id = request.get("reader_id")
    if not is_non_empty_str(reader_id):
        return error_response("invalid_id"), None
    if reader_id not in data["readers"]:
        return error_response("reader_not_found"), None

    borrows = []
    for record in data["borrows"]:
        if record["reader_id"] != reader_id or record["returned"]:
            continue
        book_id = record["book_id"]
        borrows.append(
            {
                "book_id": book_id,
                "title": data["books"][book_id]["title"],
                "borrow_date": record["borrow_date"],
                "due_date": record["due_date"],
            }
        )
    return {"ok": True, "borrows": borrows}, None


def handle_list_overdue(data, request):
    date_value = request.get("date")
    today = parse_date(date_value)
    if today is None:
        return error_response("invalid_date"), None

    reader_id = request.get("reader_id")
    if reader_id is not None:
        if not is_non_empty_str(reader_id):
            return error_response("invalid_id"), None
        if reader_id not in data["readers"]:
            return error_response("reader_not_found"), None

    overdue = []
    for record in data["borrows"]:
        if record["returned"]:
            continue
        if reader_id is not None and record["reader_id"] != reader_id:
            continue
        due = parse_date(record["due_date"])
        if due is None or not due < today:
            continue
        book_id = record["book_id"]
        overdue.append(
            {
                "book_id": book_id,
                "reader_id": record["reader_id"],
                "title": data["books"][book_id]["title"],
                "borrow_date": record["borrow_date"],
                "due_date": record["due_date"],
            }
        )
    return {"ok": True, "overdue": overdue}, None


HANDLERS = {
    "add_book": handle_add_book,
    "add_reader": handle_add_reader,
    "borrow": handle_borrow,
    "return_book": handle_return_book,
    "list_borrowed": handle_list_borrowed,
    "list_overdue": handle_list_overdue,
}


# --------------------------------------------------------------------------
# 请求分发
# --------------------------------------------------------------------------
def process(request):
    action = request.get("action")
    if not isinstance(action, str) or action not in HANDLERS:
        return error_response("unknown_action")

    data, load_error = load_data()
    if load_error is not None:
        return error_response(load_error)

    response, updated = HANDLERS[action](data, request)
    if updated is not None:
        if not save_data(updated):
            return error_response("storage_error")
    return response


def process_raw(raw):
    if not isinstance(raw, str):
        return error_response("invalid_request")
    text = raw.strip()
    if text == "":
        return error_response("invalid_request")
    try:
        parsed = json.loads(text)
    except ValueError:
        return error_response("invalid_request")
    if not isinstance(parsed, dict):
        return error_response("invalid_request")
    return process(parsed)


def main():
    try:
        raw = sys.stdin.read()
    except Exception:
        raw = ""
    try:
        response = process_raw(raw)
    except Exception:
        response = error_response("internal_error")
    try:
        sys.stdout.write(json.dumps(response, ensure_ascii=False))
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
