"""本地支出记账工具（Python 标准库实现）。

用法：通过标准输入传入一个 JSON 对象，程序执行一次请求，
并把唯一一个 JSON 对象写到标准输出，退出码始终为 0。
数据持久化在当前工作目录的 expenses.json 中。

支持的 action：add / list / total。
"""

import json
import sys
from pathlib import Path

DATA_FILE = Path("expenses.json")


class AppError(Exception):
    """可预期的业务/存储错误，携带对外错误码。"""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def parse_request(raw):
    """将标准输入文本解析为请求对象。"""
    if raw is None or raw.strip() == "":
        raise AppError("empty_input")
    try:
        request = json.loads(raw)
    except json.JSONDecodeError:
        raise AppError("invalid_json")
    if not isinstance(request, dict):
        raise AppError("invalid_request")
    return request


def validate_entry(item):
    """校验数据文件中的单条记录，返回规范化后的记录。"""
    if not isinstance(item, dict):
        raise AppError("data_corrupted")
    amount = item.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        raise AppError("data_corrupted")
    category = item.get("category")
    if not isinstance(category, str) or category.strip() == "":
        raise AppError("data_corrupted")
    return {"amount": amount, "category": category}


def validate_data(raw):
    """校验数据文件顶层结构。"""
    if not isinstance(raw, dict):
        raise AppError("data_corrupted")
    items = raw.get("entries")
    if not isinstance(items, list):
        raise AppError("data_corrupted")
    entries = []
    for item in items:
        entries.append(validate_entry(item))
    return {"entries": entries}


def load_data(path):
    """读取数据文件；不存在时初始化为空；损坏/不可读时报错且不覆盖文件。"""
    try:
        file_exists = path.exists()
    except OSError:
        raise AppError("data_unreadable")
    if not file_exists:
        return {"entries": []}
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        raise AppError("data_unreadable")
    try:
        raw = json.loads(text)
    except json.JSONDecodeError:
        raise AppError("data_corrupted")
    return validate_data(raw)


def save_data(path, data):
    """通过同目录临时文件 + 原子替换写入；失败时报错且保留旧文件。"""
    tmp_path = path.with_name(path.name + ".tmp")
    try:
        tmp_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp_path.replace(path)
    except (OSError, TypeError, ValueError):
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise AppError("data_write_failed")


def handle_add(request):
    amount = request.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        return {"ok": False, "error": "invalid_amount"}

    category = request.get("category")
    if not isinstance(category, str):
        return {"ok": False, "error": "invalid_category"}
    category = category.strip()
    if category == "":
        return {"ok": False, "error": "invalid_category"}

    data = load_data(DATA_FILE)
    entry = {"amount": amount, "category": category}
    data["entries"].append(entry)
    save_data(DATA_FILE, data)
    return {"ok": True, "entry": {"amount": amount, "category": category}}


def handle_list():
    data = load_data(DATA_FILE)
    entries = []
    for entry in data["entries"]:
        entries.append({"amount": entry["amount"], "category": entry["category"]})
    return {"ok": True, "entries": entries}


def handle_total():
    data = load_data(DATA_FILE)
    total = 0
    for entry in data["entries"]:
        total += entry["amount"]
    return {"ok": True, "total": total}


def handle_request(request):
    action = request.get("action")
    if action == "add":
        return handle_add(request)
    if action == "list":
        return handle_list()
    if action == "total":
        return handle_total()
    return {"ok": False, "error": "unknown_action"}


def main():
    try:
        raw = sys.stdin.read()
        request = parse_request(raw)
        response = handle_request(request)
    except UnicodeDecodeError:
        response = {"ok": False, "error": "invalid_json"}
    except AppError as exc:
        response = {"ok": False, "error": exc.code}

    sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
