# 本地支出记账工具

一个基于 Python 3.10+ 标准库的小型本地记账工具。每次运行只处理**一个**请求，
数据保存在当前工作目录下的 `expenses.json` 中，进程重启后数据依然保留。

## 运行方式

```bash
echo '{"action":"list"}' | python main.py
```

- 从 stdin 读取一个 JSON 对象；
- 向 stdout 写出**唯一一个** JSON 对象；
- 退出码始终为 `0`（业务错误也通过 JSON 返回）。

## 请求与响应

### add：新增一笔支出

请求字段：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `action` | string | 固定为 `"add"` |
| `amount` | 正整数（分） | 必须为正整数，布尔值非法，0/负数/小数/字符串均非法 |
| `category` | 非空字符串 | 去除首尾空白后必须非空 |

```bash
echo '{"action":"add","amount":1250,"category":"  餐饮  "}' | python main.py
```

```json
{"ok": true, "entry": {"amount": 1250, "category": "餐饮"}}
```

### list：按创建顺序列出全部记录

```bash
echo '{"action":"list"}' | python main.py
```

```json
{"ok": true, "entries": [{"amount": 1250, "category": "餐饮"}]}
```

### total：汇总总金额（单位：分，空数据为 0）

```bash
echo '{"action":"total"}' | python main.py
```

```json
{"ok": true, "total": 1250}
```

## 错误行为

所有错误都以 `{"ok": false, "error": "<错误码>"}` 形式返回，退出码仍为 0。

| 错误码 | 触发条件 |
| --- | --- |
| `invalid_amount` | `add` 的 `amount` 缺失、为布尔值、非整数或不是正整数 |
| `invalid_category` | `add` 的 `category` 缺失、不是字符串，或去空白后为空 |
| `unknown_action` | `action` 缺失或不是 `add`/`list`/`total` |
| `empty_input` | stdin 为空或只有空白字符 |
| `invalid_json` | stdin 内容不是合法 JSON（或非法 UTF-8） |
| `invalid_request` | JSON 顶层不是对象 |
| `data_unreadable` | 数据文件存在但无法读取 |
| `data_corrupted` | 数据文件内容损坏或结构不合法（不会被静默重置） |
| `data_write_failed` | 写入/替换数据文件失败（旧文件保持不变） |

示例：

```bash
echo '{"action":"add","amount":true,"category":"餐饮"}' | python main.py
# {"ok": false, "error": "invalid_amount"}

echo '{"action":"add","amount":100,"category":"   "}' | python main.py
# {"ok": false, "error": "invalid_category"}

echo '{"action":"delete"}' | python main.py
# {"ok": false, "error": "unknown_action"}
```

## 数据文件

`expenses.json` 结构：

```json
{"entries": [{"amount": 1250, "category": "餐饮"}]}
```

- 文件不存在时会自动初始化为空数据；
- 写入使用同目录临时文件（`expenses.json.tmp`）加 `Path.replace` 原子替换，
  替换失败时返回 `data_write_failed` 并保留原文件；
- 现有文件损坏、结构不合法或不可读时报错返回，**不会**被清空或覆盖。

## 约束

仅使用 Python 标准库（`json`、`sys`、`pathlib`），无网络、无子进程、无第三方依赖。
文本统一以 UTF-8 读写。
