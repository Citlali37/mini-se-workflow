# 本地支出记账工具（expense-tracker）

一个使用 Python 3.10+ 标准库实现的小型本地工具。每次调用都是一个新进程：
从 stdin 读取一个 JSON 对象，执行一次请求，stdout 只输出一个 JSON 对象，退出码为 0。

## 运行方式

```bash
echo '{"action":"total"}' | python main.py
```

启动命令固定为 `python main.py`。无需网络、第三方依赖或安装操作。

## 数据持久化

* 数据保存在当前工作目录下的 `expenses.json`。
* 文件格式：`{"entries": [{"amount": 100, "category": "food"}, ...]}`，数组顺序即创建顺序。
* 文件不存在时视为空账本（初始 total 为 0）。
* 写入使用同目录临时文件 `expenses.json.tmp` 加 `Path.replace` 原子替换；写入或替换失败时返回 JSON 错误并保留旧文件。
* 已有数据损坏或不可读时返回错误，**不会**静默重置或覆盖。

所有文本以 UTF-8 读写。

## 请求与响应

### action: add

请求字段：

* `amount`：必填，正整数（单位：分）。布尔值、浮点数、字符串、0 与负数均非法。
* `category`：必填，非空字符串；会去除首尾空白后保存。

请求：

```json
{"action": "add", "amount": 1250, "category": "  food  "}
```

响应：

```json
{"ok": true, "entry": {"amount": 1250, "category": "food"}}
```

### action: list

请求：

```json
{"action": "list"}
```

响应（按创建顺序）：

```json
{"ok": true, "entries": [{"amount": 1250, "category": "food"}]}
```

### action: total

请求：

```json
{"action": "total"}
```

响应（总金额整数，无记录时为 0）：

```json
{"ok": true, "total": 1250}
```

## 错误行为

所有错误同样以 JSON 返回，退出码仍为 0：

| 场景 | 响应 |
| --- | --- |
| 空输入 | `{"ok": false, "error": "empty_input"}` |
| 输入不是合法 JSON | `{"ok": false, "error": "invalid_json"}` |
| JSON 不是对象 | `{"ok": false, "error": "invalid_request"}` |
| 未知 / 缺失的 action | `{"ok": false, "error": "unknown_action"}` |
| 金额非法（缺失、布尔、非整数、<=0） | `{"ok": false, "error": "invalid_amount"}` |
| 分类非法（缺失、非字符串、去空白后为空） | `{"ok": false, "error": "invalid_category"}` |
| 数据文件损坏或不可读 | `{"ok": false, "error": "data_corrupted"}`（文件保留） |
| 写入或替换失败 | `{"ok": false, "error": "storage_error"}`（旧文件保留） |

`add` 校验顺序：先校验 `amount`，再校验 `category`。

## 示例会话

```bash
echo '{"action":"add","amount":100,"category":"coffee"}' | python main.py
# {"ok": true, "entry": {"amount": 100, "category": "coffee"}}

echo '{"action":"add","amount":250,"category":"book"}' | python main.py
# {"ok": true, "entry": {"amount": 250, "category": "book"}}

echo '{"action":"list"}' | python main.py
# {"ok": true, "entries": [{"amount": 100, "category": "coffee"}, {"amount": 250, "category": "book"}]}

echo '{"action":"total"}' | python main.py
# {"ok": true, "total": 350}

echo '{"action":"add","amount":0,"category":"x"}' | python main.py
# {"ok": false, "error": "invalid_amount"}
```
