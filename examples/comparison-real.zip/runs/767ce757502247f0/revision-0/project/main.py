"""本地支出记账工具（单请求单进程）。

协议：从 stdin 读取一个 JSON 对象，向 stdout 输出一个 JSON 对象，退出码 0。
持久化：当前工作目录下的 expenses.json，写入使用同目录临时文件 + Path.replace。
"""

import json
import sys
from pathlib import Path

DATA_FILE = Path("expenses.json")
TMP_FILE = Path("expenses.json.tmp")


class StorageError(Exception):
    """数据文件损坏或读写失败。"""


def load_entries():
    """读取并校验账目列表；文件不存在视为空列表，损坏则抛出 StorageError。"""
    if not DATA_FILE.exists():
        return []
    try:
        raw = DATA_FILE.read_text(encoding="utf-8")
    except OSError:
        raise StorageError()
    except UnicodeDecodeError:
        raise StorageError()

    try:
        data = json.loads(raw)
    except ValueError:
        raise StorageError()

    if not isinstance(data, dict):
        raise StorageError()

    entries = data.get("entries")
    if not isinstance(entries, list):
        raise StorageError()

    result = []
    for item in entries:
        if not isinstance(item, dict):
            raise StorageError()
        amount = item.get("amount")
        category = item.get("category")
        if isinstance(amount, bool) or not isinstance(amount, int):
            raise StorageError()
        if not isinstance(category, str) or category.strip() == "":
            raise StorageError()
        result.append({"amount": amount, "category": category})
    return result


def save_entries(entries):
    """原子写入账目列表；失败时抛出 StorageError 并保留旧文件。"""
    payload = json.dumps({"entries": entries}, ensure_ascii=False)
    try:
        TMP_FILE.write_text(payload, encoding="utf-8")
        TMP_FILE.replace(DATA_FILE)
    except OSError:
        try:
            if TMP_FILE.exists():
                TMP_FILE.unlink()
        except OSError:
            pass
        raise StorageError()


def handle_add(request):
    amount = request.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        return {"ok": False, "error": "invalid_amount"}

    category = request.get("category")
    if not isinstance(category, str):
        return {"ok": False, "error": "invalid_category"}
    category = category.strip()
    if category == "":
        return {"ok": False, "error": "invalid_category"}

    try:
        entries = load_entries()
    except StorageError:
        return {"ok": False, "error": "data_corrupted"}

    entry = {"amount": amount, "category": category}
    entries.append(entry)

    try:
        save_entries(entries)
    except StorageError:
        return {"ok": False, "error": "storage_error"}

    return {"ok": True, "entry": {"amount": amount, "category": category}}


def handle_list():
    try:
        entries = load_entries()
    except StorageError:
        return {"ok": False, "error": "data_corrupted"}
    return {"ok": True, "entries": entries}


def handle_total():
    try:
        entries = load_entries()
    except StorageError:
        return {"ok": False, "error": "data_corrupted"}
    total = 0
    for item in entries:
        total += item["amount"]
    return {"ok": True, "total": total}


def handle_request():
    try:
        raw = sys.stdin.read()
    except Exception:
        return {"ok": False, "error": "empty_input"}

    if raw.strip() == "":
        return {"ok": False, "error": "empty_input"}

    try:
        request = json.loads(raw)
    except ValueError:
        return {"ok": False, "error": "invalid_json"}

    if not isinstance(request, dict):
        return {"ok": False, "error": "invalid_request"}

    action = request.get("action")
    if action == "add":
        return handle_add(request)
    if action == "list":
        return handle_list()
    if action == "total":
        return handle_total()
    return {"ok": False, "error": "unknown_action"}


def main():
    try:
        response = handle_request()
    except Exception:
        response = {"ok": False, "error": "internal_error"}
    sys.stdout.write(json.dumps(response, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
