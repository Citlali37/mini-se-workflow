#!/usr/bin/env python3
"""文本统计工具（单次请求 / 单次响应）。

用法:
    echo '{"text": "hello-world"}' | python main.py

从 stdin 读取一个 JSON 对象，向 stdout 输出一个 JSON 对象，退出码始终为 0。
"""

import json
import re
import sys

# 连续 ASCII 字母或数字组成一个英文单词。
WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")


def build_error(code: str) -> dict:
    """构造错误响应。"""
    return {"ok": False, "error": code}


def read_stdin_text() -> str:
    """读取 stdin 的全部内容，按 UTF-8 解码为文本。"""
    stream = sys.stdin
    try:
        raw = stream.buffer.read()
    except AttributeError:
        # 没有底层字节流时退回到文本读取。
        return stream.read()
    except ValueError:
        return stream.read()
    if isinstance(raw, str):
        return raw
    return raw.decode("utf-8")


def write_response(response: dict) -> None:
    """把响应以 UTF-8 写入 stdout。"""
    payload = json.dumps(response, ensure_ascii=False) + "\n"
    stream = sys.stdout
    try:
        buffer = stream.buffer
    except AttributeError:
        stream.write(payload)
        stream.flush()
        return
    buffer.write(payload.encode("utf-8"))
    buffer.flush()


def count_characters(text: str) -> int:
    """总字符数，包含空格与换行。"""
    return len(text)


def count_words(text: str) -> int:
    """连续 ASCII 字母或数字算一个英文单词（如 hello-world 为 2 个词）。"""
    return len(WORD_PATTERN.findall(text))


def count_lines(text: str) -> int:
    """按 str.splitlines() 计算行数，空字符串为 0 行。"""
    return len(text.splitlines())


def handle_request(payload) -> dict:
    """处理已经解析成功的 JSON 请求。"""
    if not isinstance(payload, dict):
        # 顶层不是对象时，text 字段必然缺失。
        return build_error("invalid_text")
    if "text" not in payload:
        return build_error("invalid_text")
    text = payload["text"]
    if not isinstance(text, str):
        return build_error("invalid_text")
    return {
        "ok": True,
        "characters": count_characters(text),
        "words": count_words(text),
        "lines": count_lines(text),
    }


def main() -> int:
    try:
        raw = read_stdin_text()
    except UnicodeDecodeError:
        write_response(build_error("invalid_json"))
        return 0

    if not raw.strip():
        write_response(build_error("empty_input"))
        return 0

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        write_response(build_error("invalid_json"))
        return 0
    except (ValueError, TypeError):
        write_response(build_error("invalid_json"))
        return 0

    try:
        response = handle_request(payload)
    except Exception:
        # 兜底：任何未预期的失败都以 JSON 错误返回，绝不返回成功。
        write_response(build_error("internal_error"))
        return 0

    write_response(response)
    return 0


if __name__ == "__main__":
    sys.exit(main())
