# 文本统计工具（text-stats）

一个只依赖 Python 3.10+ 标准库的小型本地工具。每次运行读取**一个** JSON 请求，
输出**一个** JSON 响应后退出，退出码始终为 `0`。不需要网络、第三方依赖或数据文件。

## 运行方式

```bash
python main.py < request.json
```

或用管道：

```bash
echo '{"text": "hello-world"}' | python main.py
```

## 请求格式

从标准输入读取一个 JSON 对象，必填字段 `text`，且必须是字符串：

```json
{"text": "Hello world 123"}
```

## 响应格式

成功时返回：

```json
{"ok": true, "characters": 15, "words": 3, "lines": 1}
```

- `characters`：总字符数，包含空格与换行（等价于 `len(text)`）。
- `words`：连续 ASCII 字母或数字组成一个英文单词。`hello-world` 是 2 个词，
  `hello_world` 也是 2 个词；中文、标点、下划线都不计入单词。
- `lines`：按 `str.splitlines()` 计算的行数，空字符串为 `0` 行。

## 错误行为

错误同样只输出一个 JSON 对象，退出码仍为 `0`，不会输出部分结果：

| 情况 | 输出 |
| --- | --- |
| `text` 缺失、不是字符串，或顶层不是 JSON 对象 | `{"ok": false, "error": "invalid_text"}` |
| 标准输入为空或只有空白字符 | `{"ok": false, "error": "empty_input"}` |
| 输入不是合法 JSON（或不是 UTF-8） | `{"ok": false, "error": "invalid_json"}` |
| 其他未预期错误 | `{"ok": false, "error": "internal_error"}` |

## 使用示例

```bash
$ echo '{"text": "hello-world"}' | python main.py
{"ok": true, "characters": 11, "words": 2, "lines": 1}

$ echo '{"text": ""}' | python main.py
{"ok": true, "characters": 0, "words": 0, "lines": 0}

$ echo '{"text": 123}' | python main.py
{"ok": false, "error": "invalid_text"}

$ echo '{}' | python main.py
{"ok": false, "error": "invalid_text"}
```

## 验收用例

所有期望值都是 `characters` / `words` / `lines` 三个整数。

| # | 输入（stdin） | 期望输出 |
| --- | --- | --- |
| 1 | `{"text": "Hello world 123"}` | `{"ok": true, "characters": 15, "words": 3, "lines": 1}` |
| 2 | `{"text": "hello-world"}` | `{"ok": true, "characters": 11, "words": 2, "lines": 1}` |
| 3 | `{"text": "你好，世界"}` | `{"ok": true, "characters": 5, "words": 0, "lines": 1}` |
| 4 | `{"text": ""}` | `{"ok": true, "characters": 0, "words": 0, "lines": 0}` |
| 5 | `{"text": "a\nb\n"}` | `{"ok": true, "characters": 4, "words": 2, "lines": 2}` |
| 6 | `{"text": "a\n\nb"}` | `{"ok": true, "characters": 4, "words": 2, "lines": 3}` |
| 7 | `{"text": "  "}` | `{"ok": true, "characters": 2, "words": 0, "lines": 1}` |
| 8 | `{"text": 123}` | `{"ok": false, "error": "invalid_text"}` |
| 9 | `{}` | `{"ok": false, "error": "invalid_text"}` |
| 10 | `{"text": null}` | `{"ok": false, "error": "invalid_text"}` |
| 11 | `{"word": "hi"}` | `{"ok": false, "error": "invalid_text"}` |
| 12 | `[]` | `{"ok": false, "error": "invalid_text"}` |
| 13 | 空输入（stdin 为空） | `{"ok": false, "error": "empty_input"}` |
| 14 | `not json` | `{"ok": false, "error": "invalid_json"}` |

说明：用例 2 中 `hello-world` 由连字符分隔，按“连续 ASCII 字母或数字”计为 2 个单词。
