"""tasks.json 持久化层。

数据文件固定为当前工作目录下的 tasks.json，UTF-8 编码，结构为：
{"next_id": <int>, "tasks": [{"id": <int>, "title": <str>, "completed": <bool>}]}
文件不存在、无法解析或结构非法时，按空数据 {"next_id": 1, "tasks": []} 处理。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

TASKS_FILE = "tasks.json"


def empty_data() -> Dict[str, Any]:
    return {"next_id": 1, "tasks": []}


def path() -> Path:
    return Path.cwd() / TASKS_FILE


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _valid_task(task: Any) -> bool:
    if not isinstance(task, dict):
        return False
    if not _is_int(task.get("id")):
        return False
    if not isinstance(task.get("title"), str):
        return False
    if not isinstance(task.get("completed"), bool):
        return False
    return True


def _valid_data(data: Any) -> bool:
    if not isinstance(data, dict):
        return False
    next_id = data.get("next_id")
    if not _is_int(next_id) or next_id < 1:
        return False
    tasks = data.get("tasks")
    if not isinstance(tasks, list):
        return False
    for task in tasks:
        if not _valid_task(task):
            return False
    return True


def _normalize(data: Dict[str, Any]) -> Dict[str, Any]:
    tasks: List[Dict[str, Any]] = []
    for task in data["tasks"]:
        tasks.append(
            {
                "id": task["id"],
                "title": task["title"],
                "completed": task["completed"],
            }
        )
    tasks.sort(key=lambda task: task["id"])
    next_id = data["next_id"]
    if tasks:
        highest = max(task["id"] for task in tasks)
        if next_id <= highest:
            next_id = highest + 1
    return {"next_id": next_id, "tasks": tasks}


def load() -> Dict[str, Any]:
    """读取数据文件；任何异常或结构非法都回退为空数据。"""
    file = path()
    try:
        raw = file.read_text(encoding="utf-8")
    except Exception:
        return empty_data()
    try:
        data = json.loads(raw)
    except Exception:
        return empty_data()
    if not _valid_data(data):
        return empty_data()
    return _normalize(data)


def save(data: Dict[str, Any]) -> None:
    """以 UTF-8 覆盖写入完整数据文件。"""
    file = path()
    text = json.dumps(data, ensure_ascii=False, indent=2)
    file.write_text(text + "\n", encoding="utf-8")


def next_id(data: Dict[str, Any]) -> int:
    """返回下一个可用编号，并把 next_id 自增 1（编号永不复用）。"""
    value = data.get("next_id")
    if not _is_int(value) or value < 1:
        value = 1
    data["next_id"] = value + 1
    return value
