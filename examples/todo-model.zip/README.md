# local_todo_tool

一个使用 Python 3.10+ 标准库实现的本地待办事项工具。每次调用都是一个独立进程：
从 stdin 读取**一个** JSON 对象，执行一次请求，向 stdout 只输出**一个** JSON 对象，
退出码恒为 `0`（业务错误也通过 JSON 返回）。

## 使用方法

```bash
echo '{"action": "list"}' | python main.py
```

- 启动方式：`python main.py`（无命令行参数，无交互提示，无网络与子进程）。
- 输入：stdin 上的一个 JSON 对象，形如 `{"action": "<add|list|complete|delete>", ...}`。
- 输出：stdout 上的一个 JSON 对象（末尾带一个换行）。
- 数据：当前工作目录下的 `tasks.json`，每次请求重新读取，写操作后立即落盘。
- 退出码：始终为 `0`。

## 请求与响应

### add：新增任务

```json
{"action": "add", "title": "  Buy milk  "}
```

- 标题使用 Python `str.strip()` 去除首尾空白；`title` 不是字符串，或去空白后为空串，
  返回 `{"ok": false, "error": "empty_title"}`（数字、布尔、null、数组、对象均属此列）。
- 成功响应：

```json
{"ok": true, "task": {"id": 1, "title": "Buy milk", "completed": false}}
```

`id` 从 1 开始递增，`completed` 为 `false`。

### list：查看任务

```json
{"action": "list"}
```

```json
{"ok": true, "tasks": [{"id": 1, "title": "Buy milk", "completed": false}]}
```

任务按创建顺序（id 升序）返回；无任务时返回 `{"ok": true, "tasks": []}`。

### complete：完成任务

```json
{"action": "complete", "id": 1}
```

```json
{"ok": true, "task": {"id": 1, "title": "Buy milk", "completed": true}}
```

- `id` 必须是 JSON 整数且不能是布尔值，并且 `>= 1`；否则返回
  `{"ok": false, "error": "invalid_id"}`。
- `id` 合法但任务不存在：`{"ok": false, "error": "not_found"}`。
- 重复完成同一任务是幂等的，仍返回 `ok: true` 且 `completed` 保持 `true`。

### delete：删除任务

```json
{"action": "delete", "id": 1}
```

```json
{"ok": true, "deleted_id": 1}
```

- `id` 非法（非整数、布尔、小于 1）：`{"ok": false, "error": "invalid_id"}`。
- `id` 合法但任务不存在：`{"ok": false, "error": "not_found"}`（已删除的任务再次删除同样返回 `not_found`）。
- 删除后 `next_id` 不回退，新增任务继续使用递增编号，已删除的编号永不复用。

## 错误行为

所有失败响应都包含 `"ok": false` 与 `"error"` 字段：

| error | 触发条件 |
| --- | --- |
| `empty_title` | `add` 的 `title` 非字符串，或去空白后为空串 |
| `invalid_id` | `complete`/`delete` 的 `id` 非非布尔正整数（`0`、`-1`、`1.5`、`"1"`、`true`、`null` 等） |
| `not_found` | `id` 合法但不存在对应任务 |
| `unknown_action` | `action` 缺失、非字符串、未知值，stdin 为空或不是合法 JSON 对象 |

示例：

```bash
echo '{"action": "foo"}' | python main.py
# {"ok": false, "error": "unknown_action"}

echo '{"action": "add", "title": "   "}' | python main.py
# {"ok": false, "error": "empty_title"}
```

## 存储格式

数据保存在当前工作目录的 `tasks.json`（UTF-8、缩进 2、`ensure_ascii=false`）：

```json
{
  "next_id": 2,
  "tasks": [
    {"id": 1, "title": "Buy milk", "completed": false}
  ]
}
```

- 文件不存在时视为空任务列表，`next_id` 为 `1`，首次写操作时创建文件。
- 文件存在但 JSON 无法解析或结构不符合上述形状时，同样按 `{"next_id": 1, "tasks": []}` 处理。
- 只有 `add`/`complete`/`delete` 会写文件；错误响应不修改文件。
- 进程重启后数据不丢失，新增与完成状态通过 `list` 仍可读取。

## 验收说明

每个验收用例在各自独立的工作目录中运行，因此 `tasks.json` 互不影响；
同一用例内的多个步骤共享同一目录，但每一步都会重启进程，依赖文件持久化。
