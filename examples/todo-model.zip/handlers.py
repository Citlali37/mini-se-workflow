"""业务处理层：解析请求、访问存储、返回可 JSON 序列化的响应对象。"""

from __future__ import annotations

from typing import Any, Dict, Optional

import storage

EMPTY_TITLE = "empty_title"
INVALID_ID = "invalid_id"
NOT_FOUND = "not_found"
UNKNOWN_ACTION = "unknown_action"


def parse_title(value: Any) -> Optional[str]:
    """仅字符串可作为标题；返回去除首尾空白后的结果，否则返回 None。"""
    if not isinstance(value, str):
        return None
    return value.strip()


def parse_id(value: Any) -> Optional[int]:
    """仅接受非布尔的正整数 id，否则返回 None。"""
    if isinstance(value, bool):
        return None
    if not isinstance(value, int):
        return None
    if value < 1:
        return None
    return value


def _error(code: str) -> Dict[str, Any]:
    return {"ok": False, "error": code}


def _task_view(task: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": task["id"],
        "title": task["title"],
        "completed": bool(task["completed"]),
    }


def _find_task(data: Dict[str, Any], task_id: int) -> Optional[Dict[str, Any]]:
    for task in data["tasks"]:
        if task["id"] == task_id:
            return task
    return None


def handle_list(request: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
    tasks = sorted(data["tasks"], key=lambda task: task["id"])
    return {"ok": True, "tasks": [_task_view(task) for task in tasks]}


def handle_add(request: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
    title = parse_title(request.get("title"))
    if title is None or title == "":
        return _error(EMPTY_TITLE)

    task_id = storage.next_id(data)
    task = {"id": task_id, "title": title, "completed": False}
    data["tasks"].append(task)
    storage.save(data)
    return {"ok": True, "task": _task_view(task)}


def handle_complete(request: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
    task_id = parse_id(request.get("id"))
    if task_id is None:
        return _error(INVALID_ID)

    task = _find_task(data, task_id)
    if task is None:
        return _error(NOT_FOUND)

    task["completed"] = True
    storage.save(data)
    return {"ok": True, "task": _task_view(task)}


def handle_delete(request: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
    task_id = parse_id(request.get("id"))
    if task_id is None:
        return _error(INVALID_ID)

    task = _find_task(data, task_id)
    if task is None:
        return _error(NOT_FOUND)

    data["tasks"] = [item for item in data["tasks"] if item["id"] != task_id]
    storage.save(data)
    return {"ok": True, "deleted_id": task_id}


_HANDLERS = {
    "add": handle_add,
    "list": handle_list,
    "complete": handle_complete,
    "delete": handle_delete,
}


def dispatch(request: Any) -> Dict[str, Any]:
    """按 action 路由；缺失、非字符串或未知 action 一律返回 unknown_action。"""
    if not isinstance(request, dict):
        return _error(UNKNOWN_ACTION)
    action = request.get("action")
    if not isinstance(action, str):
        return _error(UNKNOWN_ACTION)
    handler = _HANDLERS.get(action)
    if handler is None:
        return _error(UNKNOWN_ACTION)
    data = storage.load()
    return handler(request, data)
