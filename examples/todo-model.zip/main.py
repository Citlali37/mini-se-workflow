"""local_todo_tool 入口。

协议：从 stdin 读取一个 JSON 对象，执行一次请求，向 stdout 只输出一个 JSON 对象，
退出码恒为 0。空输入、非法 JSON、非对象请求均按 unknown_action 处理。
"""

from __future__ import annotations

import json
import sys
from typing import Any, Dict

import handlers


def _read_stdin_text() -> str:
    """以 UTF-8 读取全部标准输入；读取或解码失败时返回空字符串。"""
    buffer = None
    try:
        buffer = sys.stdin.buffer
    except AttributeError:
        buffer = None
    except Exception:
        buffer = None

    if buffer is None:
        try:
            text = sys.stdin.read()
        except Exception:
            return ""
        if isinstance(text, str):
            return text
        return ""

    try:
        raw = buffer.read()
    except Exception:
        return ""

    if isinstance(raw, bytes):
        try:
            return raw.decode("utf-8")
        except Exception:
            return ""
    if isinstance(raw, str):
        return raw
    return ""


def read_request() -> Dict[str, Any]:
    """返回解析后的请求对象；任何解析失败都返回空字典。"""
    text = _read_stdin_text()
    if not text.strip():
        return {}
    try:
        obj = json.loads(text)
    except Exception:
        return {}
    if not isinstance(obj, dict):
        return {}
    return obj


def run() -> Dict[str, Any]:
    request = read_request()
    try:
        return handlers.dispatch(request)
    except Exception:
        return {"ok": False, "error": "unknown_action"}


def write_response(response: Dict[str, Any]) -> None:
    text = json.dumps(response, ensure_ascii=False)
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


def main() -> int:
    try:
        response = run()
    except Exception:
        response = {"ok": False, "error": "unknown_action"}
    try:
        write_response(response)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
