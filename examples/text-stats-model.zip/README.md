# text-stats-tool

一个基于 Python 标准库的小型本地文本统计工具。每次请求启动一个新进程，从 stdin 读取一个 JSON 对象，
统计其中的 `text` 字段，向 stdout 输出且仅输出一个 JSON 对象，退出码始终为 `0`。

无网络访问、无第三方依赖、不创建任何数据文件。

## 环境要求

- Python 3.10 或更高版本
- 仅使用标准库（`json`、`sys`、`re`、`typing`）

## 启动方式

```bash
echo '{"text": "Hello world 123"}' | python main.py
```

每次请求都是独立进程，stdin 读到 EOF 后处理并输出一行 JSON。

## 请求格式

```json
{"text": "<字符串>"}
```

- 对象中除 `text` 外的其它字段一律忽略。
- 文本编码为 UTF-8。

## 响应格式

成功时恰好包含四个字段：

```json
{"ok": true, "characters": 15, "words": 3, "lines": 1}
```

| 字段 | 含义 |
| --- | --- |
| `characters` | `len(text)`，按 Unicode 码点计数：空格、制表符、换行、中文汉字、标点各计 1 个字符 |
| `words` | 由连续 ASCII 字母或数字（正则 `[A-Za-z0-9]+`）组成的最大片段个数；汉字、下划线、连字符、空格、标点均为分隔符 |
| `lines` | `len(text.splitlines())`；空字符串为 0 行，结尾换行符不额外产生一行，CRLF 视为一个换行 |

失败时恰好包含两个字段：

```json
{"ok": false, "error": "invalid_text"}
```

## 示例

英文、空格与数字混合：

```bash
echo '{"text": "Hello world 123"}' | python main.py
# {"ok": true, "characters": 15, "words": 3, "lines": 1}
```

纯中文（中文字符计入 `characters`，`words` 为 0）：

```bash
echo '{"text": "你好，世界"}' | python main.py
# {"ok": true, "characters": 5, "words": 0, "lines": 1}
```

空文本：

```bash
echo '{"text": ""}' | python main.py
# {"ok": true, "characters": 0, "words": 0, "lines": 0}
```

多行文本（按 `splitlines()` 计行）：

```bash
printf '{"text": "a\\nb\\n\\n"}' | python main.py
# {"ok": true, "characters": 5, "words": 2, "lines": 3}
```

CRLF 换行：

```bash
printf '{"text": "line1\\r\\nline2"}' | python main.py
# {"ok": true, "characters": 12, "words": 2, "lines": 2}
```

连字符分词：

```bash
echo '{"text": "hello-world"}' | python main.py
# {"ok": true, "characters": 11, "words": 2, "lines": 1}
```

## 错误行为

当出现以下任一情况时，返回 `{"ok": false, "error": "invalid_text"}`：

- 请求对象缺少 `text` 字段：`{"foo": "bar"}`
- `text` 不是字符串（数字、布尔、`null`、数组、对象）：`{"text": 123}`、`{"text": null}`
- stdin 为空或不含合法 JSON 对象

无论成功还是业务错误，进程退出码始终为 `0`，stdout 只输出一个 JSON 对象（单行，结尾换行），
不会向 stdout 写入任何其它内容。

## 文件结构

| 文件 | 作用 |
| --- | --- |
| `main.py` | 入口：读取请求、校验 `text`、调用统计逻辑、写出响应 |
| `protocol.py` | JSON 协议层：解析 stdin、构造响应、写出单行 JSON |
| `textstats.py` | 纯统计逻辑：`count_characters` / `count_words` / `count_lines` / `analyze_text` |
| `README.md` | 使用说明 |
