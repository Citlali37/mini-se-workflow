"""JSON 协议层：读取 stdin 请求、构造响应、写出单行 JSON。"""

from __future__ import annotations

import json
from typing import Any, Optional


def read_request(stream: Any) -> Optional[Any]:
    """读取并解析 stdin 中的 JSON 对象；空输入或非法 JSON 返回 None。"""
    try:
        raw = stream.read()
    except Exception:
        return None
    if raw is None:
        return None
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            return None
    if not isinstance(raw, str) or not raw.strip():
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def success_response(stats: dict) -> dict:
    """构造成功响应，恰好四个字段。"""
    return {
        "ok": True,
        "characters": int(stats["characters"]),
        "words": int(stats["words"]),
        "lines": int(stats["lines"]),
    }


def error_response(code: str) -> dict:
    """构造失败响应，恰好两个字段。"""
    return {"ok": False, "error": code}


def write_response(stream: Any, response: dict) -> None:
    """把响应写成一行 JSON（UTF-8，ensure_ascii=False）并刷新。"""
    line = json.dumps(response, ensure_ascii=False)
    stream.write(line + "\n")
    try:
        stream.flush()
    except Exception:
        pass
