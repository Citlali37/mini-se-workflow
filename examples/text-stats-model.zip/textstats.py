"""纯统计逻辑：字符数、英文单词数、行数。不做任何 IO。"""

from __future__ import annotations

import re

WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")


def count_characters(text: str) -> int:
    """总字符数，按 Unicode 码点计数（空格、制表符、换行、汉字、标点各计 1）。"""
    return len(text)


def count_words(text: str) -> int:
    """由连续 ASCII 字母或数字组成的最大片段个数，其它字符为分隔符。"""
    return len(WORD_PATTERN.findall(text))


def count_lines(text: str) -> int:
    """行数，等于 len(text.splitlines())；空串为 0，结尾换行不额外计行。"""
    return len(text.splitlines())


def analyze_text(text: str) -> dict:
    """聚合统计，返回 {"characters": int, "words": int, "lines": int}。"""
    return {
        "characters": count_characters(text),
        "words": count_words(text),
        "lines": count_lines(text),
    }
