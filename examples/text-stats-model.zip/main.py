"""text-stats-tool 入口：从 stdin 读取一次 JSON 请求，输出一个 JSON 响应。

协议：
  请求  {"text": "<string>"}，其它字段忽略
  成功  {"ok": true, "characters": int, "words": int, "lines": int}
  失败  {"ok": false, "error": "invalid_text"}
退出码始终为 0。
"""

from __future__ import annotations

import sys
from typing import Any, Optional

import protocol
import textstats


def extract_text(request: Any) -> Optional[str]:
    """从请求对象中取出合法的 text 字符串，否则返回 None。"""
    if not isinstance(request, dict):
        return None
    text = request.get("text")
    if not isinstance(text, str):
        return None
    return text


def handle(request: Any) -> dict:
    """请求对象 -> 响应对象，唯一的分支决策点。"""
    text = extract_text(request)
    if text is None:
        return protocol.error_response("invalid_text")
    stats = textstats.analyze_text(text)
    return protocol.success_response(stats)


def run() -> int:
    """读取一个请求，写出一个响应，返回退出码 0。"""
    request = protocol.read_request(sys.stdin)
    try:
        response = handle(request)
    except Exception:
        # 任何未预期错误都以业务错误形式返回，保证退出码为 0。
        response = protocol.error_response("invalid_text")
    protocol.write_response(sys.stdout, response)
    return 0


if __name__ == "__main__":
    sys.exit(run())
