"""数据持久化：加载、校验与原子写入。"""

import json
from pathlib import Path

import validation


DATA_FILENAME = "library_data.json"
TMP_FILENAME = "library_data.json.tmp"

_TOP_KEYS = {"next_seq", "books", "readers", "borrows"}
_BOOK_KEYS = {"book_id", "title", "total_copies"}
_READER_KEYS = {"reader_id", "name"}
_BORROW_KEYS = {
    "seq",
    "book_id",
    "reader_id",
    "borrow_date",
    "due_date",
    "returned",
    "return_date",
}


class StorageError(Exception):
    """存储读取、校验或写入失败。"""


def default_data():
    return {"next_seq": 1, "books": {}, "readers": {}, "borrows": []}


def _validate_books(raw_books):
    if not isinstance(raw_books, dict):
        raise StorageError()
    books = {}
    for key, value in raw_books.items():
        if not validation.is_nonblank_str(key):
            raise StorageError()
        if not isinstance(value, dict):
            raise StorageError()
        if set(value.keys()) != _BOOK_KEYS:
            raise StorageError()
        book_id = value["book_id"]
        if not validation.is_nonblank_str(book_id) or book_id != key:
            raise StorageError()
        title = value["title"]
        if not isinstance(title, str) or title.strip() == "":
            raise StorageError()
        if title != title.strip():
            raise StorageError()
        total = value["total_copies"]
        if not validation.is_valid_int(total) or total < 1:
            raise StorageError()
        books[book_id] = {"book_id": book_id, "title": title, "total_copies": total}
    return books


def _validate_readers(raw_readers):
    if not isinstance(raw_readers, dict):
        raise StorageError()
    readers = {}
    for key, value in raw_readers.items():
        if not validation.is_nonblank_str(key):
            raise StorageError()
        if not isinstance(value, dict):
            raise StorageError()
        if set(value.keys()) != _READER_KEYS:
            raise StorageError()
        reader_id = value["reader_id"]
        if not validation.is_nonblank_str(reader_id) or reader_id != key:
            raise StorageError()
        name = value["name"]
        if not isinstance(name, str) or name.strip() == "":
            raise StorageError()
        if name != name.strip():
            raise StorageError()
        readers[reader_id] = {"reader_id": reader_id, "name": name}
    return readers


def _validate_borrows(raw_borrows, books, readers):
    if not isinstance(raw_borrows, list):
        raise StorageError()
    borrows = []
    seen_seq = set()
    unreturned_pairs = set()
    unreturned_counts = {}
    max_seq = 0
    for item in raw_borrows:
        if not isinstance(item, dict):
            raise StorageError()
        if set(item.keys()) != _BORROW_KEYS:
            raise StorageError()
        seq = item["seq"]
        if not validation.is_valid_int(seq) or seq < 1:
            raise StorageError()
        if seq in seen_seq:
            raise StorageError()
        seen_seq.add(seq)
        if seq > max_seq:
            max_seq = seq
        book_id = item["book_id"]
        reader_id = item["reader_id"]
        if not validation.is_nonblank_str(book_id) or book_id not in books:
            raise StorageError()
        if not validation.is_nonblank_str(reader_id) or reader_id not in readers:
            raise StorageError()
        borrow_date = item["borrow_date"]
        due_date = item["due_date"]
        if validation.parse_strict_date(borrow_date) is None:
            raise StorageError()
        if validation.parse_strict_date(due_date) is None:
            raise StorageError()
        returned = item["returned"]
        if not isinstance(returned, bool):
            raise StorageError()
        return_date = item["return_date"]
        if returned:
            if validation.parse_strict_date(return_date) is None:
                raise StorageError()
        else:
            if return_date is not None:
                raise StorageError()
            pair = (book_id, reader_id)
            if pair in unreturned_pairs:
                raise StorageError()
            unreturned_pairs.add(pair)
            unreturned_counts[book_id] = unreturned_counts.get(book_id, 0) + 1
        borrows.append(
            {
                "seq": seq,
                "book_id": book_id,
                "reader_id": reader_id,
                "borrow_date": borrow_date,
                "due_date": due_date,
                "returned": returned,
                "return_date": return_date,
            }
        )
    for book_id, count in unreturned_counts.items():
        if count > books[book_id]["total_copies"]:
            raise StorageError()
    borrows.sort(key=lambda record: record["seq"])
    return borrows, max_seq


def validate_data(raw):
    """校验并规范化完整数据结构，失败抛 StorageError。"""
    if not isinstance(raw, dict):
        raise StorageError()
    if set(raw.keys()) != _TOP_KEYS:
        raise StorageError()
    books = _validate_books(raw["books"])
    readers = _validate_readers(raw["readers"])
    borrows, max_seq = _validate_borrows(raw["borrows"], books, readers)
    next_seq = raw["next_seq"]
    if not validation.is_valid_int(next_seq) or next_seq < 1:
        raise StorageError()
    if next_seq <= max_seq:
        raise StorageError()
    return {"next_seq": next_seq, "books": books, "readers": readers, "borrows": borrows}


def load_data(base_dir):
    """读取数据文件；不存在则初始化，损坏则报错。"""
    path = Path(base_dir) / DATA_FILENAME
    try:
        exists = path.exists()
    except OSError:
        raise StorageError()
    if not exists:
        return default_data()
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        raise StorageError()
    try:
        raw = json.loads(text)
    except ValueError:
        raise StorageError()
    return validate_data(raw)


def save_data(base_dir, data):
    """先写同目录临时文件再 replace，失败保留原文件。"""
    path = Path(base_dir) / DATA_FILENAME
    tmp_path = Path(base_dir) / TMP_FILENAME
    try:
        text = json.dumps(data, ensure_ascii=False, indent=2)
    except (TypeError, ValueError):
        raise StorageError()
    try:
        tmp_path.write_text(text, encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        raise StorageError()
    try:
        tmp_path.replace(path)
    except OSError:
        raise StorageError()
