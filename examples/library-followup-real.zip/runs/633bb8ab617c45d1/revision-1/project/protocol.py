"""协议常量与响应构造。"""

UNKNOWN_ACTION = "unknown_action"
INVALID_ID = "invalid_id"
INVALID_TITLE = "invalid_title"
INVALID_NAME = "invalid_name"
INVALID_TOTAL_COPIES = "invalid_total_copies"
INVALID_DATE = "invalid_date"
DUPLICATE_BOOK_ID = "duplicate_book_id"
DUPLICATE_READER_ID = "duplicate_reader_id"
BOOK_NOT_FOUND = "book_not_found"
READER_NOT_FOUND = "reader_not_found"
ALREADY_BORROWED = "already_borrowed"
NO_COPIES_AVAILABLE = "no_copies_available"
NOT_BORROWED = "not_borrowed"
STORAGE_ERROR = "storage_error"

ACTIONS = (
    "add_book",
    "add_reader",
    "borrow",
    "return_book",
    "list_borrowed",
    "list_overdue",
)


def ok(**fields):
    """构造成功响应。"""
    response = {"ok": True}
    for key, value in fields.items():
        response[key] = value
    return response


def err(code):
    """构造失败响应。"""
    return {"ok": False, "error": code}
