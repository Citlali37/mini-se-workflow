"""字段与日期校验工具。"""

import datetime

_DIGITS = "0123456789"


def is_nonblank_str(value):
    """非空白字符串（去除首尾空白后非空）。"""
    return isinstance(value, str) and value.strip() != ""


def is_valid_int(value):
    """真正的整数，布尔值不算。"""
    return isinstance(value, int) and not isinstance(value, bool)


def _all_ascii_digits(text):
    if text == "":
        return False
    for ch in text:
        if ch not in _DIGITS:
            return False
    return True


def parse_strict_date(value):
    """严格解析 YYYY-MM-DD 真实日历日期，非法返回 None。"""
    if not isinstance(value, str):
        return None
    if len(value) != 10:
        return None
    if value[4] != "-" or value[7] != "-":
        return None
    year_text = value[0:4]
    month_text = value[5:7]
    day_text = value[8:10]
    if not _all_ascii_digits(year_text):
        return None
    if not _all_ascii_digits(month_text):
        return None
    if not _all_ascii_digits(day_text):
        return None
    try:
        return datetime.date(int(year_text), int(month_text), int(day_text))
    except ValueError:
        return None


def format_date(date_value):
    return date_value.isoformat()


def add_days(date_value, days):
    """日期加若干天；溢出返回 None。"""
    try:
        return date_value + datetime.timedelta(days=days)
    except (OverflowError, ValueError):
        return None
