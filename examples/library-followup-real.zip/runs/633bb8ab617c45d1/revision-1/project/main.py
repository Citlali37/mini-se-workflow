"""入口：从 stdin 读取一个 JSON 对象，向 stdout 输出一个 JSON 对象。"""

import json
import sys
from pathlib import Path

import operations
import protocol


def _read_request():
    """读取并解析 stdin 中的 JSON 对象，失败返回 None。"""
    try:
        raw = sys.stdin.read()
    except (OSError, UnicodeDecodeError):
        return None
    if raw is None or raw.strip() == "":
        return None
    try:
        parsed = json.loads(raw)
    except ValueError:
        return None
    return parsed


def _write_response(response):
    try:
        text = json.dumps(response, ensure_ascii=False)
    except (TypeError, ValueError):
        text = json.dumps({"ok": False, "error": protocol.STORAGE_ERROR}, ensure_ascii=False)
    sys.stdout.write(text)
    sys.stdout.flush()


def main():
    base_dir = Path.cwd()
    request = _read_request()
    if not isinstance(request, dict):
        _write_response(protocol.err(protocol.UNKNOWN_ACTION))
        return 0
    try:
        response = operations.handle(request, base_dir)
    except Exception:
        response = protocol.err(protocol.STORAGE_ERROR)
    _write_response(response)
    return 0


if __name__ == "__main__":
    sys.exit(main())
