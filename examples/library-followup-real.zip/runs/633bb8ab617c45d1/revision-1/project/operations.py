"""业务动作：按固定顺序校验并维护数据。"""

import protocol
import storage
import validation


DUE_DAYS = 14


def _available_copies(data, book_id):
    total = data["books"][book_id]["total_copies"]
    active = 0
    for record in data["borrows"]:
        if record["book_id"] == book_id and not record["returned"]:
            active += 1
    return total - active


def _has_unreturned(data, book_id, reader_id):
    for record in data["borrows"]:
        if record["book_id"] != book_id:
            continue
        if record["reader_id"] != reader_id:
            continue
        if not record["returned"]:
            return True
    return False


def _add_book(data, request):
    book_id = request.get("book_id")
    if not validation.is_nonblank_str(book_id):
        return protocol.err(protocol.INVALID_ID), False
    title = request.get("title")
    if not validation.is_nonblank_str(title):
        return protocol.err(protocol.INVALID_TITLE), False
    total = request.get("total_copies")
    if not validation.is_valid_int(total) or total < 1:
        return protocol.err(protocol.INVALID_TOTAL_COPIES), False
    if book_id in data["books"]:
        return protocol.err(protocol.DUPLICATE_BOOK_ID), False
    book = {"book_id": book_id, "title": title.strip(), "total_copies": total}
    data["books"][book_id] = book
    return protocol.ok(book=dict(book)), True


def _add_reader(data, request):
    reader_id = request.get("reader_id")
    if not validation.is_nonblank_str(reader_id):
        return protocol.err(protocol.INVALID_ID), False
    name = request.get("name")
    if not validation.is_nonblank_str(name):
        return protocol.err(protocol.INVALID_NAME), False
    if reader_id in data["readers"]:
        return protocol.err(protocol.DUPLICATE_READER_ID), False
    reader = {"reader_id": reader_id, "name": name.strip()}
    data["readers"][reader_id] = reader
    return protocol.ok(reader=dict(reader)), True


def _borrow(data, request):
    book_id = request.get("book_id")
    reader_id = request.get("reader_id")
    if not validation.is_nonblank_str(book_id):
        return protocol.err(protocol.INVALID_ID), False
    if not validation.is_nonblank_str(reader_id):
        return protocol.err(protocol.INVALID_ID), False
    borrow_date_text = request.get("borrow_date")
    borrow_date = validation.parse_strict_date(borrow_date_text)
    if borrow_date is None:
        return protocol.err(protocol.INVALID_DATE), False
    due_date = validation.add_days(borrow_date, DUE_DAYS)
    if due_date is None:
        return protocol.err(protocol.INVALID_DATE), False
    if book_id not in data["books"]:
        return protocol.err(protocol.BOOK_NOT_FOUND), False
    if reader_id not in data["readers"]:
        return protocol.err(protocol.READER_NOT_FOUND), False
    if _has_unreturned(data, book_id, reader_id):
        return protocol.err(protocol.ALREADY_BORROWED), False
    if _available_copies(data, book_id) <= 0:
        return protocol.err(protocol.NO_COPIES_AVAILABLE), False
    seq = data["next_seq"]
    due_date_text = validation.format_date(due_date)
    data["borrows"].append(
        {
            "seq": seq,
            "book_id": book_id,
            "reader_id": reader_id,
            "borrow_date": borrow_date_text,
            "due_date": due_date_text,
            "returned": False,
            "return_date": None,
        }
    )
    data["next_seq"] = seq + 1
    available = _available_copies(data, book_id)
    record = {
        "book_id": book_id,
        "reader_id": reader_id,
        "borrow_date": borrow_date_text,
        "due_date": due_date_text,
        "returned": False,
    }
    return protocol.ok(available_copies=available, record=record), True


def _return_book(data, request):
    book_id = request.get("book_id")
    reader_id = request.get("reader_id")
    if not validation.is_nonblank_str(book_id):
        return protocol.err(protocol.INVALID_ID), False
    if not validation.is_nonblank_str(reader_id):
        return protocol.err(protocol.INVALID_ID), False
    return_date_text = request.get("return_date")
    if validation.parse_strict_date(return_date_text) is None:
        return protocol.err(protocol.INVALID_DATE), False
    if book_id not in data["books"]:
        return protocol.err(protocol.BOOK_NOT_FOUND), False
    if reader_id not in data["readers"]:
        return protocol.err(protocol.READER_NOT_FOUND), False
    target = None
    for record in data["borrows"]:
        if record["book_id"] != book_id:
            continue
        if record["reader_id"] != reader_id:
            continue
        if not record["returned"]:
            target = record
            break
    if target is None:
        return protocol.err(protocol.NOT_BORROWED), False
    target["returned"] = True
    target["return_date"] = return_date_text
    available = _available_copies(data, book_id)
    result_record = {
        "book_id": book_id,
        "reader_id": reader_id,
        "borrow_date": target["borrow_date"],
        "due_date": target["due_date"],
        "return_date": return_date_text,
        "returned": True,
    }
    return protocol.ok(available_copies=available, record=result_record), True


def _list_borrowed(data, request):
    reader_id = request.get("reader_id")
    if not validation.is_nonblank_str(reader_id):
        return protocol.err(protocol.INVALID_ID), False
    if reader_id not in data["readers"]:
        return protocol.err(protocol.READER_NOT_FOUND), False
    borrows = []
    for record in data["borrows"]:
        if record["reader_id"] != reader_id:
            continue
        if record["returned"]:
            continue
        book = data["books"][record["book_id"]]
        borrows.append(
            {
                "book_id": record["book_id"],
                "title": book["title"],
                "borrow_date": record["borrow_date"],
                "due_date": record["due_date"],
            }
        )
    return protocol.ok(borrows=borrows), False


def _list_overdue(data, request):
    date_text = request.get("date")
    target_date = validation.parse_strict_date(date_text)
    if target_date is None:
        return protocol.err(protocol.INVALID_DATE), False
    raw_reader_id = request.get("reader_id")
    filter_reader = None
    if raw_reader_id is not None:
        if not validation.is_nonblank_str(raw_reader_id):
            return protocol.err(protocol.INVALID_ID), False
        if raw_reader_id not in data["readers"]:
            return protocol.err(protocol.READER_NOT_FOUND), False
        filter_reader = raw_reader_id
    overdue = []
    for record in data["borrows"]:
        if record["returned"]:
            continue
        if filter_reader is not None and record["reader_id"] != filter_reader:
            continue
        due_date = validation.parse_strict_date(record["due_date"])
        if due_date is None:
            continue
        if due_date < target_date:
            book = data["books"][record["book_id"]]
            overdue.append(
                {
                    "book_id": record["book_id"],
                    "reader_id": record["reader_id"],
                    "title": book["title"],
                    "borrow_date": record["borrow_date"],
                    "due_date": record["due_date"],
                }
            )
    return protocol.ok(overdue=overdue), False


_HANDLERS = {
    "add_book": _add_book,
    "add_reader": _add_reader,
    "borrow": _borrow,
    "return_book": _return_book,
    "list_borrowed": _list_borrowed,
    "list_overdue": _list_overdue,
}


def handle(request, base_dir):
    """处理一个请求并返回唯一响应对象。"""
    action = request.get("action")
    if not isinstance(action, str) or action not in protocol.ACTIONS:
        return protocol.err(protocol.UNKNOWN_ACTION)
    try:
        data = storage.load_data(base_dir)
    except storage.StorageError:
        return protocol.err(protocol.STORAGE_ERROR)
    handler = _HANDLERS.get(action)
    if handler is None:
        return protocol.err(protocol.UNKNOWN_ACTION)
    try:
        response, changed = handler(data, request)
    except storage.StorageError:
        return protocol.err(protocol.STORAGE_ERROR)
    if not response.get("ok"):
        return response
    if changed:
        try:
            storage.save_data(base_dir, data)
        except storage.StorageError:
            return protocol.err(protocol.STORAGE_ERROR)
    return response
