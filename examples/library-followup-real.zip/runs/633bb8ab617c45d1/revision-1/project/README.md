# local-library-tool

本地图书借阅工具。Python 3.10+ 标准库实现，单进程单请求：从 stdin 读取一个 JSON 对象，执行其中的动作，向 stdout 输出一个 JSON 对象，退出码恒为 0。数据保存在当前工作目录的 `library_data.json`。

## 运行方式

```
echo '{"action":"add_book","book_id":"B1","title":"T1","total_copies":1}' | python main.py
```

每次请求都是新进程，数据通过 `library_data.json` 跨进程保持。

## 输入与输出

输入必须是 JSON 对象，字段 `action` 指定动作；无法解析为 JSON 对象或动作未知时返回 `{"ok":false,"error":"unknown_action"}`。

成功：`{"ok":true,...}`；失败：`{"ok":false,"error":"<错误码>"}`。

## 动作

### add_book

`{"action":"add_book","book_id":"B1","title":"T1","total_copies":2}`

成功：`{"ok":true,"book":{"book_id":"B1","title":"T1","total_copies":2}}`

错误：`invalid_id`、`invalid_title`、`invalid_total_copies`、`duplicate_book_id`。`title` 存储前去首尾空白；`total_copies` 必须是 >=1 的整数（布尔值不算）。

### add_reader

`{"action":"add_reader","reader_id":"R1","name":"Alice"}`

成功：`{"ok":true,"reader":{"reader_id":"R1","name":"Alice"}}`

错误：`invalid_id`、`invalid_name`、`duplicate_reader_id`。`name` 存储前去首尾空白。

### borrow

`{"action":"borrow","book_id":"B1","reader_id":"R1","borrow_date":"2024-01-01"}`

成功：`{"ok":true,"available_copies":0,"record":{"book_id":"B1","reader_id":"R1","borrow_date":"2024-01-01","due_date":"2024-01-15","returned":false}}`

错误：`invalid_id`、`invalid_date`、`book_not_found`、`reader_not_found`、`already_borrowed`、`no_copies_available`。期限为借阅日加 14 个日历日，日期溢出返回 `invalid_date`。

### return_book

`{"action":"return_book","book_id":"B1","reader_id":"R1","return_date":"2024-01-10"}`

成功：`{"ok":true,"available_copies":1,"record":{"book_id":"B1","reader_id":"R1","borrow_date":"2024-01-01","due_date":"2024-01-15","return_date":"2024-01-10","returned":true}}`

错误：`invalid_id`、`invalid_date`、`book_not_found`、`reader_not_found`、`not_borrowed`。不要求归还日不早于借阅日。

### list_borrowed

`{"action":"list_borrowed","reader_id":"R1"}`

成功：`{"ok":true,"borrows":[{"book_id":"B1","title":"T1","borrow_date":"2024-01-01","due_date":"2024-01-15"}]}`

只含该读者未归还的借阅，按登记顺序。错误：`invalid_id`、`reader_not_found`。

### list_overdue

`{"action":"list_overdue","date":"2024-01-16","reader_id":"R1"}`

成功：`{"ok":true,"overdue":[{"book_id":"B1","reader_id":"R1","title":"T1","borrow_date":"2024-01-01","due_date":"2024-01-15"}]}`

含所有未归还且 `due_date < date` 的记录，按登记顺序；`due_date` 等于 `date` 不算逾期。`reader_id` 可省略。错误：`invalid_date`、`reader_not_found`。

## 日期规则

日期必须是严格的 `YYYY-MM-DD`（四位年-两位月-两位日）且为真实日历日期。`2024-1-2`、`2024-02-30`、`2024-13-01` 均返回 `invalid_date`。

## 数据与错误行为

数据文件为当前工作目录的 `library_data.json`，默认结构为 `{"next_seq":1,"books":{},"readers":{},"borrows":[]}`。写入采用同目录临时文件 `library_data.json.tmp` 再替换，保证失败时旧文件不变。

文件不存在时按默认结构初始化；文件损坏、JSON 非法、字段缺失或类型错误、非法引用、重复未归还、超库存、读写失败时返回 `storage_error` 并保留原文件，不会静默重置。任何失败请求都不会改变已保存的数据。
