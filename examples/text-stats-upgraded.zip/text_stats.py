"""Pure text statistics helpers (no IO, no side effects).

Definitions:
    characters = len(text)                       (spaces, tabs and newlines included)
    words      = number of [A-Za-z0-9]+ matches   (hyphen/underscore/punctuation are separators)
    lines      = len(text.splitlines())           (empty string -> 0)
"""

import re

WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")


def is_valid_text(value):
    """Return True only when value is a str."""
    return isinstance(value, str)


def count_characters(text):
    """Total number of characters, including spaces and newlines."""
    return len(text)


def count_words(text):
    """Number of runs of ASCII letters or digits."""
    return len(WORD_PATTERN.findall(text))


def count_lines(text):
    """Number of lines, following Python's str.splitlines() semantics."""
    return len(text.splitlines())


def compute_stats(text):
    """Build the success response for a validated text string."""
    return {
        "ok": True,
        "characters": count_characters(text),
        "words": count_words(text),
        "lines": count_lines(text),
    }


def build_error(error_code):
    """Build the failure response for the given error code."""
    return {"ok": False, "error": error_code}
