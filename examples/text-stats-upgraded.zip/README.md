# text_stats_tool

一个零依赖的本地文本统计工具，使用 Python 3.10+ 标准库实现。
每次请求启动一个新进程：从 stdin 读取一个 JSON 对象，向 stdout 写出一个 JSON 对象，退出码恒为 0。

## 运行方式

```bash
python main.py
```

stdin 传入一个 JSON 对象（可带尾随换行），stdout 只输出一个 JSON 对象，没有任何日志或提示信息。

```bash
echo '{"text": "hello world"}' | python main.py
# {"ok": true, "characters": 11, "words": 2, "lines": 1}
```

## 请求字段

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `text` | string | 要统计的文本。顶层其他字段一律忽略。 |

## 响应

成功：

```json
{"ok": true, "characters": 11, "words": 2, "lines": 1}
```

失败（`text` 缺失或不是字符串，例如 null、数字、布尔、数组、对象）：

```json
{"ok": false, "error": "invalid_text"}
```

两种情况下退出码都是 0。

## 统计定义

- `characters`：`len(text)`，即 Python 字符个数，空格、制表符、换行各计 1。
- `words`：正则 `[A-Za-z0-9]+` 在 `text` 上的非重叠匹配数量。
  即只有连续的 ASCII 字母或数字才算一个词；连字符 `-`、下划线 `_`、标点、空白、换行以及
  所有非 ASCII 字符（如中文、日文、重音字母）都是分隔符。
  例如 `hello-world` 计为 2 个词，`你好世界` 计为 0 个词。
- `lines`：`len(text.splitlines())`，与 Python 的 `str.splitlines()` 语义一致。
  空字符串返回 0 行，`"a\nb\n"` 返回 2 行。

类型校验顺序：只要 `text` 缺失或不是 `str`，立即返回 `invalid_text`，不做任何统计。

## 请求 / 响应示例

| 输入 | 输出 |
| --- | --- |
| `{"text": "hello world"}` | `{"ok": true, "characters": 11, "words": 2, "lines": 1}` |
| `{"text": "hello-world"}` | `{"ok": true, "characters": 11, "words": 2, "lines": 1}` |
| `{"text": "你好世界"}` | `{"ok": true, "characters": 4, "words": 0, "lines": 1}` |
| `{"text": ""}` | `{"ok": true, "characters": 0, "words": 0, "lines": 0}` |
| `{"text": "a\nb\n"}` | `{"ok": true, "characters": 4, "words": 2, "lines": 2}` |
| `{"text": "第一行\nsecond line 42\n"}` | `{"ok": true, "characters": 19, "words": 3, "lines": 2}` |
| `{"text": "  hello,  world!  "}` | `{"ok": true, "characters": 18, "words": 2, "lines": 1}` |
| `{"text": 123}` | `{"ok": false, "error": "invalid_text"}` |
| `{}` | `{"ok": false, "error": "invalid_text"}` |
| `{"text": null}` | `{"ok": false, "error": "invalid_text"}` |

## 模块结构

- `main.py`：入口与 JSON 协议层，负责读取 stdin、调用统计逻辑、写出 stdout 并返回退出码 0。
- `text_stats.py`：纯统计逻辑（`is_valid_text`、`count_characters`、`count_words`、`count_lines`、
  `compute_stats`、`build_error`），不读写任何文件或标准流。

## 其他说明

- 无网络、无第三方依赖、无子进程、无系统命令。
- 每次请求都是独立新进程，不保存任何持久化数据。
- 文本以 UTF-8 读写，输出使用 `ensure_ascii=False`，中文按原样输出。