"""Entry point and stdin/stdout JSON protocol layer for the text statistics tool.

Usage:
    python main.py

Reads a single JSON object from stdin, writes a single JSON object to stdout,
and always exits with status code 0.
"""

import json
import sys

import text_stats


def read_request(stream=sys.stdin):
    """Read the whole input stream and parse it as JSON.

    Returns the parsed object, or None when the payload is not valid JSON.
    """
    raw = stream.read()
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def write_response(payload, stream=sys.stdout):
    """Write exactly one JSON object (plus newline) to the output stream."""
    stream.write(json.dumps(payload, ensure_ascii=False) + "\n")
    stream.flush()


def handle_request(request):
    """Turn a parsed request object into a response object."""
    if not isinstance(request, dict):
        return text_stats.build_error("invalid_text")
    if "text" not in request:
        return text_stats.build_error("invalid_text")
    text = request["text"]
    if not text_stats.is_valid_text(text):
        return text_stats.build_error("invalid_text")
    return text_stats.compute_stats(text)


def main(argv=None):
    """Execute one request and return the process exit code (always 0)."""
    request = read_request(sys.stdin)
    try:
        response = handle_request(request)
    except Exception:
        response = text_stats.build_error("invalid_text")
    write_response(response)
    return 0


if __name__ == "__main__":
    sys.exit(main())
