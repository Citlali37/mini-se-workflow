"""add/list/total 的业务逻辑与输入校验。

校验顺序固定为 action（main.py 负责）-> amount -> category；
任何校验失败的请求都不会触碰持久化存储。
"""

import storage

INVALID_AMOUNT = "invalid_amount"
INVALID_CATEGORY = "invalid_category"


def validate_amount(request):
    """返回 (amount, None) 或 (None, "invalid_amount")。"""
    if "amount" not in request:
        return None, INVALID_AMOUNT
    amount = request["amount"]
    if isinstance(amount, bool):
        return None, INVALID_AMOUNT
    if not isinstance(amount, int):
        return None, INVALID_AMOUNT
    if amount <= 0:
        return None, INVALID_AMOUNT
    return amount, None


def validate_category(request):
    """返回 (去首尾空白后的 category, None) 或 (None, "invalid_category")。"""
    if "category" not in request:
        return None, INVALID_CATEGORY
    category = request["category"]
    if not isinstance(category, str):
        return None, INVALID_CATEGORY
    cleaned = category.strip()
    if cleaned == "":
        return None, INVALID_CATEGORY
    return cleaned, None


def handle_add(request, path):
    amount, amount_error = validate_amount(request)
    if amount_error is not None:
        return {"ok": False, "error": amount_error}

    category, category_error = validate_category(request)
    if category_error is not None:
        return {"ok": False, "error": category_error}

    entry = {"amount": amount, "category": category}
    storage.append_entry(path, entry)
    return {"ok": True, "entry": {"amount": amount, "category": category}}


def handle_list(request, path):
    entries = storage.load_entries(path)
    return {"ok": True, "entries": entries}


def handle_total(request, path):
    entries = storage.load_entries(path)
    total = 0
    for entry in entries:
        total += entry["amount"]
    return {"ok": True, "total": total}
