# local_expense_tracker

本地支出记账工具，只用 Python 3.10+ 标准库实现。每次请求都是一个新的 `python main.py` 进程：

- 从 **stdin** 读取一个 JSON 对象
- 向 **stdout** 写出唯一一个 JSON 对象
- 退出码恒为 `0`（业务错误也用 JSON 表示）
- 数据持久化到当前工作目录下的 `expenses.json`，跨进程重启保持

## 运行方式

```bash
echo '{"action": "add", "amount": 1250, "category": "Food"}' | python main.py
echo '{"action": "list"}' | python main.py
echo '{"action": "total"}' | python main.py
```

也可以重定向文件：`python main.py < request.json`。

## 请求协议

```json
{"action": "add", "amount": 1250, "category": "Food"}
{"action": "list"}
{"action": "total"}
```

- `amount`：必须是 `int` 且不是 `bool`，且大于 0；`float`、字符串、`null`、缺失、`true/false` 均非法。
- `category`：必须是字符串，去除首尾空白后非空；存储的是去空白后的值。

## 响应与错误

成功：

```json
{"ok": true, "entry": {"amount": 1250, "category": "Food"}}
{"ok": true, "entries": [{"amount": 1250, "category": "Food"}]}
{"ok": true, "total": 1250}
```

失败：

```json
{"ok": false, "error": "invalid_request"}
{"ok": false, "error": "invalid_amount"}
{"ok": false, "error": "invalid_category"}
{"ok": false, "error": "unknown_action"}
{"ok": false, "error": "storage_corrupted"}
{"ok": false, "error": "storage_write_failed"}
```

错误说明：

- `invalid_request`：stdin 为空、不是合法 JSON，或顶层不是对象。
- `invalid_amount`：`add` 时 amount 非法；校验优先于 category（两者同时非法时返回它）。
- `invalid_category`：`add` 时 category 非法（缺失、null、数字、空串、纯空白）。
- `unknown_action`：action 缺失、非字符串或不是 `add`/`list`/`total`。
- `storage_corrupted`：`expenses.json` 存在但不可读、非法 JSON、顶层非对象、`entries` 非数组或元素结构非法。此时不会把它当作空账本继续写入。
- `storage_write_failed`：临时文件写入或替换失败；原 `expenses.json` 保持原内容不变。

任何校验失败或未知操作的请求都不会写入存储。

## 存储格式

`expenses.json`（运行时数据文件，当前工作目录下）：

```json
{"entries": [{"amount": 100, "category": "coffee"}, {"amount": 300, "category": "tea"}]}
```

- `entries` 按创建顺序保存，元素仅含 `amount` 与 `category` 两个字段。
- 文件不存在 → 视为空账本（`list` 返回 `[]`，`total` 返回 `0`）。
- 写入采用“同目录临时文件 + `Path.replace` 原子替换”：失败时删除临时文件、保留旧文件，并返回 `storage_write_failed`。
- `amount` 与 `total` 使用 Python 任意精度整数，不存在溢出问题。
