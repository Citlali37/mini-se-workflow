"""expenses.json 的读取与原子写入。

文件格式：{"entries": [{"amount": int, "category": str}, ...]}。
文件不存在视为空账本；文件存在但损坏/不可读一律报错，绝不静默重置。
"""

import json
import random
from pathlib import Path


class StorageCorrupted(Exception):
    """expenses.json 存在但内容不可信（不可读、非法 JSON 或结构非法）。"""


class StorageWriteFailed(Exception):
    """原子写入 expenses.json 失败，原文件保持不变。"""


def _coerce_entry(item):
    if not isinstance(item, dict):
        raise StorageCorrupted("entry is not an object")
    if "amount" not in item or "category" not in item:
        raise StorageCorrupted("entry missing required fields")
    amount = item["amount"]
    category = item["category"]
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
        raise StorageCorrupted("entry amount is invalid")
    if not isinstance(category, str) or category.strip() == "":
        raise StorageCorrupted("entry category is invalid")
    return {"amount": amount, "category": category}


def load_entries(path):
    """读取全部条目，按创建顺序返回；文件不存在返回空列表。"""
    target = Path(path)
    try:
        exists = target.exists()
    except OSError as exc:
        raise StorageCorrupted("cannot stat data file") from exc
    if not exists:
        return []

    try:
        text = target.read_text(encoding="utf-8")
    except OSError as exc:
        raise StorageCorrupted("data file is unreadable") from exc
    except UnicodeDecodeError as exc:
        raise StorageCorrupted("data file is not valid utf-8") from exc

    try:
        data = json.loads(text)
    except ValueError as exc:
        raise StorageCorrupted("data file is not valid json") from exc

    if not isinstance(data, dict):
        raise StorageCorrupted("data file root is not an object")
    if "entries" not in data:
        raise StorageCorrupted("data file has no entries field")
    entries = data["entries"]
    if not isinstance(entries, list):
        raise StorageCorrupted("entries is not an array")

    result = []
    for item in entries:
        result.append(_coerce_entry(item))
    return result


def _remove_tmp(tmp):
    try:
        if tmp.exists():
            tmp.unlink()
    except OSError:
        pass


def _atomic_write(path, payload):
    target = Path(path)
    directory = target.parent
    tmp = directory / (target.name + ".tmp." + str(random.randrange(1000000000)))
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
        tmp.replace(target)
    except OSError as exc:
        _remove_tmp(tmp)
        raise StorageWriteFailed("cannot write data file") from exc
    except Exception as exc:
        _remove_tmp(tmp)
        raise StorageWriteFailed("cannot write data file") from exc


def append_entry(path, entry):
    """读-改-写：先读取现有条目，追加后同目录临时文件原子替换。"""
    entries = load_entries(path)
    record = {"amount": entry["amount"], "category": entry["category"]}
    entries.append(record)
    try:
        payload = json.dumps({"entries": entries}, ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        raise StorageWriteFailed("cannot serialize data file") from exc
    _atomic_write(path, payload)
