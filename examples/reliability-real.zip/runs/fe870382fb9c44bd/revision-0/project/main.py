"""本地支出记账工具入口。

协议：从 stdin 读取一个 JSON 对象，只向 stdout 输出一个 JSON 对象，退出码恒为 0。
"""

import json
import sys
from pathlib import Path

import handlers
import storage

DATA_FILE = "expenses.json"

KNOWN_ACTIONS = ("add", "list", "total")

INVALID_REQUEST = "invalid_request"
UNKNOWN_ACTION = "unknown_action"
STORAGE_CORRUPTED = "storage_corrupted"
STORAGE_WRITE_FAILED = "storage_write_failed"
INTERNAL_ERROR = "internal_error"


def emit(result):
    """向 stdout 写出唯一一个 JSON 对象，绝不抛出异常。"""
    try:
        text = json.dumps(result, ensure_ascii=False)
    except (TypeError, ValueError):
        text = json.dumps({"ok": False, "error": INTERNAL_ERROR})
    try:
        sys.stdout.write(text + "\n")
        sys.stdout.flush()
    except Exception:
        try:
            sys.stdout.write(json.dumps({"ok": False, "error": INTERNAL_ERROR}) + "\n")
            sys.stdout.flush()
        except Exception:
            pass


def read_stdin_text():
    try:
        raw = sys.stdin.read()
    except (OSError, ValueError):
        return ""
    if not isinstance(raw, str):
        return ""
    return raw


def parse_request(raw):
    """返回顶层 dict，输入非法时返回 None。"""
    text = raw.strip()
    if text == "":
        return None
    try:
        request = json.loads(text)
    except ValueError:
        return None
    if not isinstance(request, dict):
        return None
    return request


def dispatch(request, path):
    action = request["action"] if "action" in request else None
    if not isinstance(action, str) or action not in KNOWN_ACTIONS:
        return {"ok": False, "error": UNKNOWN_ACTION}
    if action == "add":
        return handlers.handle_add(request, path)
    if action == "list":
        return handlers.handle_list(request, path)
    return handlers.handle_total(request, path)


def run():
    raw = read_stdin_text()
    request = parse_request(raw)
    if request is None:
        emit({"ok": False, "error": INVALID_REQUEST})
        return

    path = Path(DATA_FILE)
    try:
        result = dispatch(request, path)
    except storage.StorageCorrupted:
        result = {"ok": False, "error": STORAGE_CORRUPTED}
    except storage.StorageWriteFailed:
        result = {"ok": False, "error": STORAGE_WRITE_FAILED}
    except (OverflowError, ArithmeticError):
        result = {"ok": False, "error": INTERNAL_ERROR}
    except MemoryError:
        result = {"ok": False, "error": INTERNAL_ERROR}
    except OSError:
        result = {"ok": False, "error": STORAGE_CORRUPTED}
    except Exception:
        result = {"ok": False, "error": INTERNAL_ERROR}

    if not isinstance(result, dict):
        result = {"ok": False, "error": INTERNAL_ERROR}
    emit(result)


if __name__ == "__main__":
    run()
