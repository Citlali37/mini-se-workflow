"""协议层：stdin JSON 解析、text 字段校验与响应构造。

本模块只负责协议与输入校验，不做任何计数逻辑。
"""

import json
import sys

INVALID_JSON = "invalid_json"
INVALID_TEXT = "invalid_text"
INTERNAL_ERROR = "internal_error"


class RequestError(Exception):
    """业务/协议级错误，携带错误标识 code。"""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def parse_request(raw):
    """把 stdin 原始字节解析为顶层对象 dict。

    解码失败、空输入、JSON 语法错误、顶层不是对象时抛
    RequestError('invalid_json')。
    """
    if raw is None:
        raise RequestError(INVALID_JSON)
    try:
        content = raw.decode("utf-8-sig")
    except (UnicodeDecodeError, AttributeError):
        raise RequestError(INVALID_JSON)
    if not content.strip():
        raise RequestError(INVALID_JSON)
    try:
        request = json.loads(content)
    except (ValueError, TypeError):
        raise RequestError(INVALID_JSON)
    if not isinstance(request, dict):
        raise RequestError(INVALID_JSON)
    return request


def extract_text(request):
    """取出 text 字段；缺失或不是字符串时抛 RequestError('invalid_text')。"""
    if "text" not in request:
        raise RequestError(INVALID_TEXT)
    value = request["text"]
    if type(value) is not str:
        raise RequestError(INVALID_TEXT)
    return value


def ok_response(characters, words, lines):
    return {"ok": True, "characters": characters, "words": words, "lines": lines}


def error_response(code):
    return {"ok": False, "error": code}


def write_response(response):
    """把响应写为单个 JSON 对象；每个进程只调用一次。"""
    sys.stdout.write(json.dumps(response, ensure_ascii=False))
    sys.stdout.flush()
