# text_stats_tool

一个小型的本地文本统计工具。每次请求启动一个新进程：从 stdin 读取一个 JSON 对象，向 stdout 写回一个 JSON 对象，退出码恒为 0（含错误请求）。无网络、无子进程、无第三方依赖、无持久化。

## 运行方式

```bash
echo '{"text": "hello-world 123!"}' | python main.py
```

输出：

```json
{"ok": true, "characters": 16, "words": 3, "lines": 1}
```

也可以用重定向：

```bash
python main.py < request.json
```

## 请求格式

- stdin 必须是 UTF-8 编码（允许 BOM）的 JSON 对象。
- 字段 `text` 必须是字符串；缺失或非字符串均报错。
- 其他字段一律忽略，字段名区分大小写。
- stdin 为空、仅空白、不是合法 JSON，或顶层不是对象时返回 `invalid_json`。

请求示例：

```json
{"text": "中文abc_123 x-y"}
```

## 响应格式

成功（`ok` 为 true，另含三个整数）：

```json
{"ok": true, "characters": 13, "words": 4, "lines": 1}
```

失败（`ok` 为 false，另含 `error`）：

```json
{"ok": false, "error": "invalid_text"}
```

## 计数定义

- `characters`：`len(text)`，按 Python str 的 Unicode 码点计数；空格、换行、制表符、标点、中文、emoji 各计 1。
- `words`：正则 `[A-Za-z0-9]+` 的匹配片段个数，即连续 ASCII 字母或数字算一个单词。下划线、连字符、空白、标点和非 ASCII 字母都是分隔符，本身不计入单词。
- `lines`：`len(text.splitlines())`。空字符串为 0 行；末尾换行不追加空行；连续两个换行计 2 行；行边界遵循 Python `str.splitlines` 识别的 Unicode 换行符。

## 边界示例

| text | characters | words | lines |
| --- | --- | --- | --- |
| `hello-world 123!` | 16 | 3 | 1 |
| `你好，世界` | 5 | 0 | 1 |
| 空字符串 | 0 | 0 | 0 |
| `a\nb\n`（末行有换行） | 4 | 2 | 2 |
| `\n\n`（两个连续空行） | 2 | 0 | 2 |
| `中文abc_123 x-y` | 13 | 4 | 1 |

## 错误行为

| error | 触发条件 |
| --- | --- |
| `invalid_json` | stdin 为空/仅空白、无法按 UTF-8 解码、不是合法 JSON、或顶层不是 JSON 对象 |
| `invalid_text` | 顶层对象缺失 `text` 键，或 `text` 不是字符串（null、布尔、数字、数组、对象） |
| `internal_error` | 防御性兜底，正常流程不应出现 |

错误请求同样只输出一个 JSON 对象，退出码仍为 0，不会打印堆栈或额外文本。

## 自检

```bash
python selftest.py
```

在进程内直接调用协议层与计算层，覆盖上述全部边界用例并输出汇总 JSON，例如 `{"ok": true, "total": 11, "passed": 11, "failed": []}`。不启动子进程、不读写数据文件。

## 约束说明

- 仅使用 Python 3.10+ 标准库（`json`、`sys`、`re`）。
- 不使用网络、子进程、系统命令、动态导入或交互提示。
- 不做持久化：不创建、不读取、不写入任何数据文件，进程之间不保留状态。