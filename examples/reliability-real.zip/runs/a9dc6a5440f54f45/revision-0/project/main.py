"""text_stats_tool 入口：从 stdin 读取一个 JSON 请求，向 stdout 写出一个 JSON 响应。

每次请求均为新进程，无持久化状态；无论成功或业务错误，退出码恒为 0。
"""

import sys

import protocol
import stats


def handle(raw):
    """处理原始 stdin 字节，返回响应 dict；不向调用方抛出异常。"""
    try:
        request = protocol.parse_request(raw)
        text = protocol.extract_text(request)
        result = stats.compute(text)
        return protocol.ok_response(
            result["characters"], result["words"], result["lines"]
        )
    except protocol.RequestError as exc:
        return protocol.error_response(exc.code)
    except Exception:
        return protocol.error_response(protocol.INTERNAL_ERROR)


def main():
    try:
        raw = sys.stdin.buffer.read()
    except Exception:
        raw = b""
    response = handle(raw)
    try:
        protocol.write_response(response)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
