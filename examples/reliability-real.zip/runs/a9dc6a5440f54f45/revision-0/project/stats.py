"""纯计算层：characters / words / lines 的 Python 语义计数，无 I/O。"""

import re

WORD_RE = re.compile(r"[A-Za-z0-9]+")


def count_characters(text):
    """Unicode 码点数；空格、换行、标点、中文、emoji 各计 1。"""
    return len(text)


def count_words(text):
    """连续 ASCII 字母数字片段数；下划线、连字符、非 ASCII 字母均为分隔符。"""
    return len(WORD_RE.findall(text))


def count_lines(text):
    """等价 len(text.splitlines())；空串为 0，末尾换行不追加空行。"""
    return len(text.splitlines())


def compute(text):
    """返回 {"characters": int, "words": int, "lines": int}；纯函数无异常路径。"""
    return {
        "characters": count_characters(text),
        "words": count_words(text),
        "lines": count_lines(text),
    }
