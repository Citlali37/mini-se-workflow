"""进程内自检：直接调用 protocol 与 stats 覆盖全部验收用例，不启动子进程。

运行：python selftest.py
输出一个汇总 JSON 对象；全部通过时 ok 为 true。
"""

import json

import protocol
import stats

CASES = (
    (
        "A1",
        {"text": "hello-world 123!"},
        {"ok": True, "characters": 16, "words": 3, "lines": 1},
    ),
    (
        "A2",
        {"text": "你好，世界"},
        {"ok": True, "characters": 5, "words": 0, "lines": 1},
    ),
    (
        "A3",
        {"text": ""},
        {"ok": True, "characters": 0, "words": 0, "lines": 0},
    ),
    (
        "A4",
        {"text": "a\nb\n"},
        {"ok": True, "characters": 4, "words": 2, "lines": 2},
    ),
    (
        "A5",
        {"text": "\n\n"},
        {"ok": True, "characters": 2, "words": 0, "lines": 2},
    ),
    ("A6", {}, {"ok": False, "error": "invalid_text"}),
    ("A7-1", {"text": 123}, {"ok": False, "error": "invalid_text"}),
    ("A7-2", {"text": None}, {"ok": False, "error": "invalid_text"}),
    ("A7-3", {"text": ["a"]}, {"ok": False, "error": "invalid_text"}),
    ("A7-4", {"text": {"a": 1}}, {"ok": False, "error": "invalid_text"}),
    (
        "A8",
        {"text": "中文abc_123 x-y"},
        {"ok": True, "characters": 13, "words": 4, "lines": 1},
    ),
)


def contains(actual, expected):
    """递归包含比较：对象按字段包含，数组长度与顺序精确比较。"""
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return False
        for key in expected:
            if key not in actual:
                return False
            if not contains(actual[key], expected[key]):
                return False
        return True
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            return False
        for index in range(len(expected)):
            if not contains(actual[index], expected[index]):
                return False
        return True
    return type(actual) is type(expected) and actual == expected


def run(request):
    """把请求 dict 编码为 stdin 字节后走完整协议链路，返回响应 dict。"""
    raw = json.dumps(request, ensure_ascii=False).encode("utf-8")
    try:
        parsed = protocol.parse_request(raw)
        text = protocol.extract_text(parsed)
    except protocol.RequestError as exc:
        return protocol.error_response(exc.code)
    result = stats.compute(text)
    return protocol.ok_response(result["characters"], result["words"], result["lines"])


def main():
    failures = []
    for name, request, expected in CASES:
        actual = run(request)
        if not contains(actual, expected):
            failures.append(
                {
                    "case": name,
                    "input": request,
                    "expected": expected,
                    "actual": actual,
                }
            )
    summary = {
        "ok": not failures,
        "total": len(CASES),
        "passed": len(CASES) - len(failures),
        "failed": failures,
    }
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
