# text_stats_tool

无状态的小型本地文本统计工具，仅使用 Python 3.10+ 标准库。从标准输入读取一个 JSON 对象，向标准输出写入一个 JSON 对象，不联网、不启动子进程、不写入任何文件。

## 使用方法

```
python main.py
```

每次请求由新进程处理：程序读完全部 stdin，解析 JSON，统计后输出一行 JSON，退出码恒为 0。

## 请求协议

```
{"text": "hello world"}
```

- 仅使用字段 `text`；多余的字段一律忽略。
- `text` 必须是 JSON 字符串（用 `type(text) is str` 精确判断，布尔值、数字、null、数组、对象均不合法）。

## 响应协议

成功：

```json
{"ok": true, "characters": 11, "words": 2, "lines": 1}
```

失败（唯一错误标识 `invalid_text`）：

```json
{"ok": false, "error": "invalid_text"}
```

以下情况均返回 `invalid_text`（退出码仍为 0）：

- 标准输入为空、JSON 解析失败或顶层不是 JSON 对象；
- 缺少 `text` 字段；
- `text` 存在但不是字符串，例如 `123`、`null`、`true`、`["x"]`、`{"a": 1}`。

## 统计口径

- `characters`：`len(text)`，按 Unicode 码点计数，空格和换行都计入。
- `words`：正则 `[A-Za-z0-9]+` 的匹配数量；连字符、下划线、标点、空白以及非 ASCII 字符都作为分隔符。
- `lines`：`len(text.splitlines())`；空字符串得到 0，末尾单个换行不额外增加行数，连续换行产生的空行计入。

示例：

| 输入 text | characters | words | lines |
| --- | --- | --- | --- |
| `hello world` | 11 | 2 | 1 |
| `hello-world` | 11 | 2 | 1 |
| `中文abc 123` | 9 | 2 | 1 |
| `` （空串） | 0 | 0 | 0 |
| `a\nb\n` | 4 | 2 | 2 |
| `a\n\nb` | 4 | 2 | 3 |

## 调用示例

```
echo '{"text": "hello-world"}' | python main.py
```

输出：

```json
{"ok": true, "characters": 11, "words": 2, "lines": 1}
```

```
echo '{"foo": "bar"}' | python main.py
```

输出：

```json
{"ok": false, "error": "invalid_text"}
```

## 说明

工具完全无状态，运行期间不读取或写入任何文件，也不保存缓存或数据库，因此不存在数据文件损坏或需要重置的情况；计数使用 Python 任意精度整数，不会溢出。
