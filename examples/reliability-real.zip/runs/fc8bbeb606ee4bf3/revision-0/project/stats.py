"""纯函数文本统计模块：无 IO、无状态。"""

import re

WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")


def count_characters(text: str) -> int:
    """总字符数，按 Unicode 码点计数，空格与换行均计入。"""
    return len(text)


def count_words(text: str) -> int:
    """连续 ASCII 字母或数字构成的单词数，其余字符均视为分隔。"""
    return len(WORD_PATTERN.findall(text))


def count_lines(text: str) -> int:
    """行数，等价于 len(text.splitlines())，空串为 0。"""
    return len(text.splitlines())


def summarize(text: str) -> dict:
    """返回 characters / words / lines 三个统计值。"""
    return {
        "characters": count_characters(text),
        "words": count_words(text),
        "lines": count_lines(text),
    }
