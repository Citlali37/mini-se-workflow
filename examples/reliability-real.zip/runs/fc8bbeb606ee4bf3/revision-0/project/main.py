"""text_stats_tool 入口：从 stdin 读取一个 JSON 对象，输出一个 JSON 对象。"""

import json
import sys

from stats import summarize

INVALID_TEXT = "invalid_text"


def validate(payload):
    """校验请求负载，合法返回 None，否则返回错误标识字符串。"""
    if type(payload) is not dict:
        return INVALID_TEXT
    if "text" not in payload:
        return INVALID_TEXT
    if type(payload["text"]) is not str:
        return INVALID_TEXT
    return None


def build_response(payload):
    """根据请求负载构造响应字典。"""
    error = validate(payload)
    if error is not None:
        return {"ok": False, "error": error}
    stats = summarize(payload["text"])
    return {
        "ok": True,
        "characters": stats["characters"],
        "words": stats["words"],
        "lines": stats["lines"],
    }


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw)
    except ValueError:
        payload = None
    result = build_response(payload)
    sys.stdout.write(json.dumps(result, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    main()
