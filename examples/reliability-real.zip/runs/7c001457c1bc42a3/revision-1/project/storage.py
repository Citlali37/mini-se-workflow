"""Persistence layer for the local expense tracker."""

import json
from pathlib import Path

DATA_FILE_NAME = "expenses.json"
TEMP_FILE_NAME = "expenses.json.tmp"


class StorageError(Exception):
    """Raised when the data file cannot be read or written safely."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def _data_path() -> Path:
    return Path.cwd() / DATA_FILE_NAME


def _temp_path() -> Path:
    return Path.cwd() / TEMP_FILE_NAME


def load_entries() -> list:
    """Return the stored entries; a missing file means an empty ledger."""
    path = _data_path()
    if not path.exists():
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as error:
        raise StorageError("storage_unreadable") from error
    try:
        payload = json.loads(text)
    except ValueError as error:
        raise StorageError("storage_corrupted") from error
    if not isinstance(payload, dict):
        raise StorageError("storage_corrupted")
    raw_entries = payload.get("entries")
    if not isinstance(raw_entries, list):
        raise StorageError("storage_corrupted")
    entries = []
    for raw in raw_entries:
        if not isinstance(raw, dict):
            raise StorageError("storage_corrupted")
        amount = raw.get("amount")
        category = raw.get("category")
        if type(amount) is not int or amount < 1:
            raise StorageError("storage_corrupted")
        if type(category) is not str or category == "" or category.strip() != category:
            raise StorageError("storage_corrupted")
        entries.append({"amount": amount, "category": category})
    return entries


def save_entries(entries: list) -> None:
    """Atomically write the entries, keeping the old file on failure."""
    path = _data_path()
    temp_path = _temp_path()
    payload = {"entries": entries}
    try:
        with temp_path.open("w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False)
            stream.flush()
        temp_path.replace(path)
    except OSError as error:
        _discard(temp_path)
        raise StorageError("write_failed") from error
    except (TypeError, ValueError) as error:
        _discard(temp_path)
        raise StorageError("write_failed") from error


def _discard(path: Path) -> None:
    try:
        if path.exists():
            path.unlink()
    except OSError:
        pass
