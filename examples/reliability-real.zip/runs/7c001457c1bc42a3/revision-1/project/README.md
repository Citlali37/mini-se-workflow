# expense-tracker-local

一个使用 Python 3.10+ 标准库实现的本地支出记账工具。每次启动都是一个独立进程：
从标准输入读取 **一个** JSON 对象，执行一次请求，向标准输出写出 **一个** JSON 对象，
退出码始终为 0。

## 运行方式

```bash
echo '{"action": "add", "amount": 500, "category": "  food  "}' | python main.py
```

输出：

```json
{"ok": true, "entry": {"amount": 500, "category": "food"}}
```

## 操作

| action | 请求字段 | 成功响应 |
| --- | --- | --- |
| add | amount（正整数）、category（非空字符串） | {"ok": true, "entry": {"amount": 整数, "category": "去空白后的字符串"}} |
| list | 无 | {"ok": true, "entries": [{"amount": 整数, "category": "字符串"}, ...]} |
| total | 无 | {"ok": true, "total": 整数} |

- list 的 entries 按创建顺序排列，无数据时为 []。
- total 为所有条目 amount 之和，无数据时为 0。
- add 成功时 category 会去除首尾空白后再保存。

## 错误行为

错误同样以单个 JSON 对象返回，形式为 {"ok": false, "error": "错误标识"}：

| 错误标识 | 触发条件 |
| --- | --- |
| invalid_amount | add 的 amount 缺失、不是整数（含布尔值、浮点数、字符串、null）或小于 1 |
| invalid_category | add 的 category 缺失、不是字符串，或去除首尾空白后为空 |
| unknown_action | action 缺失、不是字符串或不属于 add/list/total |
| storage_corrupted | 数据文件存在但内容损坏（非法 JSON、顶层非对象、entries 非数组、条目字段非法） |
| storage_unreadable | 数据文件存在但无法读取 |
| write_failed | 写入数据文件失败，原文件保持不变 |
| internal_error | 未预期的内部错误 |

校验顺序：add 先校验 amount，再校验 category；校验失败时不会读取账本之外的写入动作，也不会写入数据。

## 持久化

- 数据保存在当前工作目录下的相对路径 `expenses.json`。
- 文件不存在时视为空账本，list 返回 []，total 返回 0。
- 文件存在但损坏或不可读时返回错误，不会静默重置或覆盖原文件。
- 写入时先在同目录创建临时文件 `expenses.json.tmp`，写完通过 `Path.replace` 原子替换；
  任一步失败都会删除临时文件并保留原有数据。
- 文件格式：

```json
{"entries": [{"amount": 100, "category": "books"}]}
```
