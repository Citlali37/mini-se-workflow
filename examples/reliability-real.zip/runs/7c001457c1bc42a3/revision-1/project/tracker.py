"""Business logic for the local expense tracker."""

from storage import StorageError, load_entries, save_entries

_ACTIONS = ("add", "list", "total")


def _is_valid_amount(value: object) -> bool:
    return type(value) is int and value >= 1


def _is_valid_category(value: object) -> bool:
    return type(value) is str and value.strip() != ""


def handle(request: dict) -> dict:
    """Execute a single request and return the response object."""
    action = request.get("action")
    if type(action) is not str or action not in _ACTIONS:
        return {"ok": False, "error": "unknown_action"}

    if action == "list":
        try:
            entries = load_entries()
        except StorageError as error:
            return {"ok": False, "error": error.code}
        return {"ok": True, "entries": entries}

    if action == "total":
        try:
            entries = load_entries()
        except StorageError as error:
            return {"ok": False, "error": error.code}
        total = 0
        for entry in entries:
            total += entry["amount"]
        return {"ok": True, "total": total}

    amount = request.get("amount")
    if not _is_valid_amount(amount):
        return {"ok": False, "error": "invalid_amount"}

    category = request.get("category")
    if not _is_valid_category(category):
        return {"ok": False, "error": "invalid_category"}
    normalized_category = category.strip()

    try:
        entries = load_entries()
    except StorageError as error:
        return {"ok": False, "error": error.code}

    entry = {"amount": amount, "category": normalized_category}
    try:
        save_entries(entries + [entry])
    except StorageError as error:
        return {"ok": False, "error": error.code}
    return {"ok": True, "entry": entry}
