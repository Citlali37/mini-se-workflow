"""Entry point for the local expense tracker.

Reads one JSON object from stdin, executes a single action and writes one
JSON object to stdout.  The process always exits with status code 0.
"""

import json
import sys

from tracker import handle


def _read_request() -> dict:
    """Read stdin and return a JSON object, or an empty dict when unusable."""
    raw = sys.stdin.read()
    try:
        request = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    if not isinstance(request, dict):
        return {}
    return request


def main() -> None:
    request = _read_request()
    try:
        response = handle(request)
    except Exception:
        response = {"ok": False, "error": "internal_error"}
    sys.stdout.write(json.dumps(response, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
